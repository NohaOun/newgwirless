<?php
namespace App\Admin\Controllers;

class AdminCustomFieldController extends \SCart\Core\Admin\Controllers\AdminCustomFieldController
{
    public function __construct()
    {
        parent::__construct();
    }
}
