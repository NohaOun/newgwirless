<?php
namespace App\Admin\Controllers;

class AdminAttributeGroupController extends \SCart\Core\Admin\Controllers\AdminAttributeGroupController
{
    public function __construct()
    {
        parent::__construct();
    }

}
