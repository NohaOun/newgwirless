<?php

namespace App\Admin\Controllers\Auth;

class LoginController extends \SCart\Core\Admin\Controllers\Auth\LoginController
{
    public function __construct()
    {
        parent::__construct();
    }
}
