<?php
namespace App\Admin\Controllers\Auth;

class PermissionController extends \SCart\Core\Admin\Controllers\Auth\PermissionController
{
    public function __construct()
    {
        parent::__construct();
    }
}
