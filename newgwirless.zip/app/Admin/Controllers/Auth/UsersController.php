<?php
namespace App\Admin\Controllers\Auth;

class UsersController extends \SCart\Core\Admin\Controllers\Auth\UsersController
{
    public function __construct()
    {
        parent::__construct();
    }

}
