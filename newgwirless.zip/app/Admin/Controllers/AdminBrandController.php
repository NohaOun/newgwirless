<?php
namespace App\Admin\Controllers;

class AdminBrandController extends \SCart\Core\Admin\Controllers\AdminBrandController
{
    public function __construct()
    {
        parent::__construct();
    }
}
