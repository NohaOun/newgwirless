<?php
namespace App\Admin\Controllers;

class AdminSubscribeController extends \SCart\Core\Admin\Controllers\AdminSubscribeController
{
    public function __construct()
    {
        parent::__construct();
    }
}
