<?php
namespace App\Admin\Controllers;

class AdminPageController extends \SCart\Core\Admin\Controllers\AdminPageController
{
    public function __construct()
    {
        parent::__construct();
    }

}
