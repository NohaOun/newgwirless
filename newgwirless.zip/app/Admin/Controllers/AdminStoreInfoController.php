<?php
namespace App\Admin\Controllers;

class AdminStoreInfoController extends \SCart\Core\Admin\Controllers\AdminStoreInfoController
{
    public function __construct()
    {
        parent::__construct();

    }
}
