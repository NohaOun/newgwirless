<?php
namespace App\Admin\Controllers;

class AdminProductController extends \SCart\Core\Admin\Controllers\AdminProductController
{

    public function __construct()
    {
        parent::__construct();

    }
}
