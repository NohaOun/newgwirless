<?php
namespace App\Admin\Controllers;

class AdminCategoryController extends  \SCart\Core\Admin\Controllers\AdminCategoryController
{

    public function __construct()
    {
        parent::__construct();
    }

}
