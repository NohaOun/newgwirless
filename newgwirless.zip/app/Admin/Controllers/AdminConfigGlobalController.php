<?php
namespace App\Admin\Controllers;

class AdminConfigGlobalController extends \SCart\Core\Admin\Controllers\AdminConfigGlobalController
{
    public function __construct()
    {
        parent::__construct();
    }

}
