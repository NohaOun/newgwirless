<?php
namespace App\Admin\Controllers;

class AdminBackupController extends \SCart\Core\Admin\Controllers\AdminBackupController
{

    public function __construct()
    {
        parent::__construct();
    }

}
