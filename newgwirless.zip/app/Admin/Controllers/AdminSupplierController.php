<?php
namespace App\Admin\Controllers;

class AdminSupplierController extends \SCart\Core\Admin\Controllers\AdminSupplierController
{

    public function __construct()
    {
        parent::__construct();
    }

}
