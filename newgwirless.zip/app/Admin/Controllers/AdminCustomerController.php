<?php
namespace App\Admin\Controllers;

class AdminCustomerController extends \SCart\Core\Admin\Controllers\AdminCustomerController
{
    public function __construct()
    {
        parent::__construct();
    }
}
