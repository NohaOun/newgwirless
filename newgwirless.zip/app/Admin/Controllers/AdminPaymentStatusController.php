<?php
namespace App\Admin\Controllers;

class AdminPaymentStatusController extends \SCart\Core\Admin\Controllers\AdminPaymentStatusController
{

    public function __construct()
    {
        parent::__construct();
    }

}
