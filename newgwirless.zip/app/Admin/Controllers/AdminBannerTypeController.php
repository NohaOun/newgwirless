<?php
namespace App\Admin\Controllers;

class AdminBannerTypeController extends \SCart\Core\Admin\Controllers\AdminBannerTypeController
{
    public function __construct()
    {
        parent::__construct();
    }
}
