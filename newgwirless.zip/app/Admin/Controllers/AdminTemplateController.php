<?php
namespace App\Admin\Controllers;

class AdminTemplateController extends \SCart\Core\Admin\Controllers\AdminTemplateController
{
    public function __construct()
    {
        parent::__construct();
    }
}
