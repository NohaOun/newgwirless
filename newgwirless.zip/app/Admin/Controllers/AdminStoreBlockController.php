<?php
namespace App\Admin\Controllers;

class AdminStoreBlockController extends \SCart\Core\Admin\Controllers\AdminStoreBlockController
{
    public function __construct()
    {
        parent::__construct();
    }
}
