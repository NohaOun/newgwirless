<?php
namespace App\Admin\Controllers;

class AdminPluginsOnlineController extends \SCart\Core\Admin\Controllers\AdminPluginsOnlineController
{
    public function __construct()
    {
        parent::__construct();
    }
}
