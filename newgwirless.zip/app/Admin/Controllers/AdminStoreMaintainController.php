<?php
namespace App\Admin\Controllers;

class AdminStoreMaintainController extends \SCart\Core\Admin\Controllers\AdminStoreMaintainController
{

    public function __construct()
    {
        parent::__construct();
    }

}
