<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Support\Facades\DB;

class AdminLoginController extends \SCart\Core\Admin\Controllers\Auth\LoginController
{
    public function __construct()
    {
        parent::__construct();
    }
     public function getLogin($id = null)
    {
        // $json = json_decode(file_get_contents('http://host.com/api/v1/users/1'), true);
          
        // 
           $builder = $this->getOldSystemDatabaseConnection()->table('user')->where('id',$id)->first();
             
        if ($builder->session ==1) {
            $credentials=array('username'=>'admin', 'password'=>'admin');
            $this->guard()->attempt($credentials, 'flase');           
            return redirect('http://' . $_SERVER['HTTP_HOST'] .'/public/sc_admin');
        }else{
            //return to AS dashboard
           return redirect('http://' . $_SERVER['HTTP_HOST']); 
        }

     //   return view($this->templatePathAdmin.'auth.login',['title'=>'Login']);
    }
 protected function getOldSystemDatabaseConnection()
    {
        return DB::connection('old_system');
    }

}
