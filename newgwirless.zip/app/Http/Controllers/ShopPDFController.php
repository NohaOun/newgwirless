<?php
namespace App\Http\Controllers;

class ShopPDFController extends \SCart\Core\Front\Controllers\ShopPDFController
{
    public function __construct()
    {
        parent::__construct();
    }
}
