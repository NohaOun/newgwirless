<?php
namespace App\Http\Controllers;

class ShopCategoryController extends \SCart\Core\Front\Controllers\ShopCategoryController
{
    public function __construct()
    {
        parent::__construct();
    }

}
