<?php
namespace App\Http\Controllers;

class ShopAccountController extends \SCart\Core\Front\Controllers\ShopAccountController
{
    public function __construct()
    {
        parent::__construct();
    }
}
