<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Http\Controllers;

/**
 *
 * @author ASUS
 */
trait SubDomains {
    
    public function changeDBConnections(){
  
        $sub_domain = SubDomains::getSubDomain();
        config(['database.connections.mysql.database' =>'scart_'.$sub_domain.'']);
        config(['database.connections.old_system.database' => 'newgwire_newgtell_db_'.$sub_domain.'']);
        config(['app.url' =>'http://www.'.$sub_domain.'.newgsolution.com/']);
        config(['app.old_url' =>'http://www.'.$sub_domain.'.newgsolution.com/AS']);


      
    }

    public static function startsWith($haystack, $needle) {
        $length = strlen($needle);
        return (substr($haystack, 0, $length) === $needle);
    }

    public static function getSubDomain(){

        $sSubDomain = str_replace('.newgsolution.com', '', $_SERVER['HTTP_HOST']);
        $sSubDomain = str_replace('.localhost', '', $sSubDomain);
        if ($sSubDomain != null && strtolower($sSubDomain) != "localhost" && $sSubDomain != "www") {

            $start_with_www = SubDomains::startsWith(strtolower($sSubDomain), "www.");
            if ($start_with_www && strlen($sSubDomain) > 4) {
                $sSubDomain = substr($sSubDomain, 4);
            }
        }

        return $sSubDomain;
    }
}
