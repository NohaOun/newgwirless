<?php

return [
    'title' => 'Chuyển khoản ngân hàng',
    'info' => 'Thông tin chuyển khoản',
];
