<?php
return [
    'title'                       => 'PaypalExpress',
    'id'                          => 'ID',
    'paypal_currency'             => 'Currency',
    'paypal_order_status_success' => 'Order success',
    'paypal_order_status_faild'   => 'Order faild',
    'paypal_payment_status'       => 'Payment status',
    'paypal_mode'                 => 'Paypal mode',
    'paypal_client_id'            => 'Client ID',
    'paypal_secrect'              => 'Secrect Key',
    'currency_not_allow'          => 'Can not use :currency for this payment method.',
    'currency_only_allow'         => 'List currency allow :currency.',
    'paypal_load_config'          => 'Load config from',
    'admin'                       => [
            'title'                   => 'PaypalExpress',
    ],
];
