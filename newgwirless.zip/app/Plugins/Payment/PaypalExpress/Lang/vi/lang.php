<?php
return [
    'title'                       => 'PaypalExpress',
    'id'                          => 'ID',
    'paypal_currency'             => 'Loại tiền',
    'paypal_order_status_success' => 'Trạng thái thành công',
    'paypal_order_status_faild'   => 'Trạng thái thất bại',
    'paypal_payment_status'       => 'Trạng thái thanh toán',
    'paypal_mode'                 => 'Paypal mode',
    'paypal_client_id'            => 'Client ID',
    'paypal_secrect'              => 'Secrect Key',
    'currency_not_allow'          => 'Không thể sử dụng :currency cho phương thức thanh toán này.',
    'currency_only_allow'         => 'Danh sách chấp nhận :currency.',
    'paypal_load_config'            => 'Tải thông tin cấu hình từ',
    'admin'      => [
        'title'          => 'PaypalExpress',
    ],
];
