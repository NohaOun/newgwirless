<?php

return [
    'title'                       => 'MOMO payment basic',
    'momo_env'                    => 'Enviroment',
    'momo_load_config'            => 'Load config from',
    'momo_accessKey'             => 'Access key',
    'momo_secretKey'             => 'Secrect key',
    'momo_partnerCode'             => 'Partner code',
    'momo_order_status_success'   => 'Order status when success',
    'momo_order_status_faild'       => 'Order status when faild',
    'momo_payment_status'             => 'Payment status when success',
    'data_response_not_match'       => 'Data response not match :field',
    'currency_not_allow' => 'Can not use :currency for this payment method.',
    'order_not_found'   =>  'Order not found',
    'currency_only_allow' => 'Curency only allow in [:list]',
    'config_field'            => 'Field',
    'config_value'            => 'Value',
];
