<?php 
return [
    'momo_accessKey' => env('momo_accessKey', ''),
    'momo_secretKey' => env('momo_secretKey', ''),
    'momo_partnerCode' => env('momo_partnerCode', ''),
];