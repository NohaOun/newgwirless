<?php

return [
    'title' => 'Thanh toán tiền mặt',
];
