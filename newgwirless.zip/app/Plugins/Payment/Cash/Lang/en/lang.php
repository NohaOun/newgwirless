<?php

return [
    'title' => 'Cash on delivery',
];
