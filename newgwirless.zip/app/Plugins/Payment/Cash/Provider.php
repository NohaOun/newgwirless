<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Payment/Cash');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Payment/Cash');