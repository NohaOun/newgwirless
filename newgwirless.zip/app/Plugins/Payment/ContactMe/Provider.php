<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Payment/ContactMe');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Payment/ContactMe');