<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Shipping/ShippingExpress');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Shipping/ShippingExpress');