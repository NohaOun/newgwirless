<?php
Route::group(
    [
        'prefix'    => 'plugin/shipping/ShippingExpress',
        'namespace' => 'App\Plugins\Shipping\ShippingExpress\Controllers',
    ], function () {
        Route::post('updateConfig', 'FrontController@updateConfig')
            ->name('shippingexpress.updateConfig');
    });