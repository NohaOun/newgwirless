<?php

return [
    'title'         => 'Shipping Express',
    'id'            => 'ID',
    'shipping_free' => 'Total to free ship',
    'fee'           => 'Fee',
    'sort'          => 'Sort',
    'add_more'      => 'Add more',
    'remove'        => 'Remove',
];
