<?php

return [
    'title'         => 'Shipping Free',
    'id'            => 'ID',
    'shipping_free' => 'Total to free ship',
    'fee'           => 'Fee',
    'sort'          => 'Sort',
    'add_more'      => 'Add more',
    'remove'        => 'Remove',
];
