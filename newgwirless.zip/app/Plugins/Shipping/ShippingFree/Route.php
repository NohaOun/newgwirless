<?php
Route::group(
    [
        'prefix'    => 'plugin/shipping/ShippingFree',
        'namespace' => 'App\Plugins\Shipping\ShippingFree\Controllers',
    ], function () {
        Route::post('updateConfig', 'FrontController@updateConfig')
            ->name('shippingfree.updateConfig');
    });