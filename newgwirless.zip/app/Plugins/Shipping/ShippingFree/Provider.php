<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Shipping/ShippingFree');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Shipping/ShippingFree');