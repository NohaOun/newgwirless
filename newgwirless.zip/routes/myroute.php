<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Customize web Routes
|--------------------------------------------------------------------------
|
 */
 //Route::post('auth/login?token', '\App\Http\Controllers\Auth\loginController@postLogin')->name('login');

    //Route::get('login/{id}', 'Auth\LoginController@getLogin')->name('admin.login');
