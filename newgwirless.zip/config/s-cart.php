<?php
return [
    'version'     => '6.4',
    'sub-version' => '6.4.0',
    'type'        => 'basic',
    'homepage'    => 'http://newgsolution.com/',
    'title'       => 'Open Source eCommerce for Business',
];
