<!DOCTYPE html>
<html class="wide wow-animation" lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700%7CLato%7CKalam:300,400,700">
    <meta name="description" content="{{ $description??sc_store('description') }}">
    <meta name="keyword" content="{{ $keyword??sc_store('keyword') }}">
    <title>{{sc_store('title')}}-{{$title??sc_store('title')}}</title>
    <meta name="google-site-verification" content="C1CeOs9O0X8bL3GvoikAk36q8iJjQl2XdTa6x_-cBJw" />
    <link rel="icon" href="{{config('app.url')}}/{{ sc_store('icon', null, 'images/icon.png') }}" type="image/png" sizes="16x16">
     <?php 
                    $url = config('app.url');
                        if (strpos($url, '//www.') !== false)
                        {
                            $url = str_replace("//www.", "//", $url);
                        }
                    ?>
    <meta property="og:image" content="{{ $url}}{{sc_store_logo() }}" />
    <meta property="og:url" content="{{ \Request::fullUrl() }}" />
    <meta property="og:type" content="Website" />
    <meta property="og:title" content="{{ $title??sc_store('title') }}" />
    <meta property="og:description" content="{{ $description??sc_store('description') }}" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
<script data-require="jquery@3.1.1" data-semver="3.1.1" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="{{ sc_file($sc_templateFile.'/button/button.js')}}"></script>
  <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/button/style.css')}}" media="all" />

<!-- css default for item s-cart -->
    @include($sc_templatePath.'.common.css')
    <!--//end css defaut -->
    <!-- css default for item s-cart -->
    <!--//end css defaut -->

    <!--Module header -->
    @isset ($sc_blocksContent['header'])
    @foreach ( $sc_blocksContent['header'] as $layout)
    @php
    $arrPage = explode(',', $layout->page)
    @endphp
    @if ($layout->page == '*' || (isset($layout_page) && in_array($layout_page, $arrPage)))
        @if ($layout->type =='html')
            {!! $layout->text !!}
        @elseif($layout->type =='view')
            @includeIf($sc_templatePath.'.block.'.$layout->text)
        @endif
    @endif
    @endforeach
    @endisset
    <!--//Module header -->
<script src="{{ sc_file($sc_templateFile.'/js/js/vendor/jquery.js')}}"></script>
<script src="{{ sc_file($sc_templateFile.'/js/dist/xzoom.min.js')}}"></script>
<link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/js/dist/xzoom.css')}}" media="all" />
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"crossorigin="anonymous"></script>
		<script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/menu/dist/jquery.dmenu.css')}}">
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/menu/demo/css/demo.css')}}">
    <script src="{{ sc_file($sc_templateFile.'/menu/dist/jquery.dmenu.js')}}"></script>
<style>
			.header-menu
			{
				background: rgba(0,0,0,0.4);
				width: 100%;
				position: absolute;
				top: 0;
				left: 0;
			}
			.dm-menu
			{
				--dm-bg: transparent;
				--dm-color: #fff;
				--dm-item-hover-bg: #fff;
				--dm-item-hover-color: #fff;
				--dm-menu-height: 100px;
			}
			.header-slider
			{
				height: 300px;
			}
		</style>

		<script src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

  <!-- xzoom plugin here -->
  <script type="text/javascript" src="../dist/xzoom.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../dist/xzoom.css" media="all" /> 
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/fonts.css')}}">
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/style.css')}}">
    @if($style==0)
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/style.css')}}">
    @else
     <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/style_'.$style.'.css')}}">
    @endif
    <style>
        {!! sc_store_css() !!}
    </style>
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
    @stack('styles')
  </head>
<body>
    <div class="ie-panel">
        <a href="http://windows.microsoft.com/en-US/internet-explorer/">
            <img src="{{ sc_file($sc_templateFile.'/images/ie8-panel/warning_bar_0000_us.jpg')}}" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today.">
        </a>
    </div>

    <div class="page">
        {{-- Block header --}}
        @section('block_header')
        @include($sc_templatePath.'.block_header')
        @show
        {{--// Block header --}}

        {{-- Block top --}}
        @section('block_top')
        @include($sc_templatePath.'.block_top')
        @show
        {{-- //Block top --}}

        {{-- Block main --}}
        @section('block_main')
        <section class="section section-xxl bg-default text-md-left">
            <div class="container">
                <div class="row row-50">
                    @section('block_main_content')
                    @include($sc_templatePath.'.block_main_content_left')
                    @include($sc_templatePath.'.block_main_content_center')
                    @include($sc_templatePath.'.block_main_content_right')
                    @show
                </div>
            </div>
        </section>
        @show
        {{-- //Block main --}}

        {{-- Block bottom --}}
        @section('block_bottom')
            @include($sc_templatePath.'.block_bottom')
        @show
        {{-- //Block bottom --}}

        {{-- Block footer --}}
        @section('block_footer')
            @include($sc_templatePath.'.block_footer')
        @show
        {{-- //Block footer --}}

    </div>

    <div id="sc-loading">
        <div class="sc-overlay"><i class="fa fa-spinner fa-pulse fa-5x fa-fw "></i></div>
    </div>

    <script src="{{ sc_file($sc_templateFile.'/js/core.min.js')}}"></script>
    <script src="{{ sc_file($sc_templateFile.'/js/script.js')}}"></script>
    
<script type="text/javascript">
      $(document).ready(function () {
//change selectboxes to selectize mode to be searchable
   $("#select2").select2();
});
//	window.addEventListener("resize", function() {
//		"use strict"; window.location.reload(); 
//	});


	document.addEventListener("DOMContentLoaded", function(){
        

    	/////// Prevent closing from click inside dropdown
		document.querySelectorAll('.dropdown-menu').forEach(function(element){
			element.addEventListener('click', function (e) {
			  e.stopPropagation();
			});
		})



		// make it as accordion for smaller screens
		if (window.innerWidth < 992) {

			// close all inner dropdowns when parent is closed
			document.querySelectorAll('.navbar .dropdown').forEach(function(everydropdown){
				everydropdown.addEventListener('hidden.bs.dropdown', function () {
					// after dropdown is hidden, then find all submenus
					  this.querySelectorAll('.submenu').forEach(function(everysubmenu){
					  	// hide every submenu as well
					  	everysubmenu.style.display = 'none';
					  });
				})
			});
			
			document.querySelectorAll('.dropdown-menu a').forEach(function(element){
				element.addEventListener('click', function (e) {
		
				  	let nextEl = this.nextElementSibling;
				  	if(nextEl && nextEl.classList.contains('submenu')) {	
				  		// prevent opening link if link needs to open dropdown
				  		e.preventDefault();
				  		console.log(nextEl);
				  		if(nextEl.style.display == 'block'){
				  			nextEl.style.display = 'none';
				  		} else {
				  			nextEl.style.display = 'block';
				  		}

				  	}
				});
			})
		}
		// end if innerWidth

	}); 
	// DOMContentLoaded  end
</script>

    <!-- js default for item s-cart -->
    @include($sc_templatePath.'.common.js')
    <!--//end js defaut -->
    @stack('scripts')

</body>
</html>