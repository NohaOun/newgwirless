@php
$banners = $modelBanner->start()->setType('banner')->getData()
@endphp
@if (!empty($banners))

<section class="section swiper-container swiper-slider swiper-slider-1" data-loop="true" style="width: 900px !important; height:260px !important;margin-top:30px">
  <div class="swiper-wrapper text-center text-lg-left">
    @foreach ($banners as $key => $banner)
  
       <div class="swiper-slide swiper-slide-caption context-dark" data-slide-bg="{{ sc_file($banner->image) }}">
      <div class="swiper-slide-caption section-md text-center">
        <div class="container">
              <a style="width:100%" href="{{ sc_route('banner.click',['id' => $banner->id]) }}" target="{{ $banner->target }}">
          {!! sc_html_render($banner->html) !!}
      </a>  
        </div>
      </div>
    </div>
           
    @endforeach
  </div>
  <!-- Swiper Pagination-->
  <div class="swiper-pagination"></div>
  <!-- Swiper Navigation-->
  <div class="swiper-button-prev"></div>
  <div class="swiper-button-next"></div>
</section>
<!--slider-->
@endif