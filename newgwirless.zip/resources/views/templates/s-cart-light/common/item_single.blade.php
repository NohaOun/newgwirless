<article class="post post-classic box-md"><a class="post-classic-figure" href="{{ sc_route('category.detail', ['alias' => $item->id]);}}">
 @if($item->image)
        <img src="{{ config('app.old_url')}}/{{ $item->image }}" alt="" width="370" height="239"></a>
 @endif
    <h5 class="post-classic-title"><a href="{{ sc_route('category.detail', ['alias' => $item->id]);}}">{{ $item->title }}</a></h5>
</article>