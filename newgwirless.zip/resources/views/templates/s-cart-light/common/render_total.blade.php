@if (!empty($dataTotal) && count($dataTotal))
<table class="table box table-bordered" id="showTotal">
  
          @if($dataTotal[0]['code']=='subtotal')
            <tr class="showTotal">
                <th>{!! $dataTotal[0]['title'] !!}</th>
                <td style="text-align: right" id="{{ $dataTotal[0]['code'] }}">
                    {{$dataTotal[0]['text'] }}
                </td>
            </tr>
            @endif 
             @if($dataTotal[1]['code']=='tax')
            <tr class="showTotal">
                <th>{!! $dataTotal[1]['title'] !!}</th>
                <td style="text-align: right" id="{{ $dataTotal[1]['code'] }}">

                    ${{number_format((float)$tax, 2,  '.', '')}}
                </td>
            </tr>
          @endif 
   <tr class="showTotal" style="" id="getShipping">
            <th>Shipping</th><td style="text-align: right" id="shipping">$0.00</td>
            </tr>                
        @if ($dataTotal[3]['code']=='total')
            <tr class="showTotal" style="background:#f5f3f3;font-weight: bold;">
                <th>{!! $dataTotal[3]['title'] !!}</th>
                <td style="text-align: right" id="{{ $dataTotal[3]['code'] }}" >
                    <input style="border:0px;background-color: #f5f3f3;text-align: right;padding:0px !important" type="text" value="{{$dataTotal[3]['text'] }}" id="newTotal" />
                    <input  type="hidden" value="{{$dataTotal[3]['value'] }}" id="oldTotal" />
                </td>
            </tr>                  
      
        @endif

                              
      
   
</table>
@endif
