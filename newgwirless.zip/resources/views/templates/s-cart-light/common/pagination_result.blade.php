<p class="product-top-panel-title">   
  {!! sc_language_render('front.result_item', ['item_from' => $items->firstItem(), 'item_to'=> $items->lastItem(), 'total'=> $items->total()  ]) !!}
</p>