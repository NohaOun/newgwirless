<div class="col-md-12">
    <div class="table-responsive">
        <table class="table box table-bordered">
            <thead>
                <tr style="background: #eaebec">
                    <th style="width: 50px;">No.</th>
                    <th>{{ sc_language_render('product.name') }}</th>
                    <th>{{ sc_language_render('product.price') }}</th>
                    <th>{{ sc_language_render('product.quantity') }}</th>
                    <th>{{ sc_language_render('product.subtotal') }}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @php $cost=0; @endphp
                @foreach($cartItem as $item)
                @php
                $n = (isset($n)?$n:0);
                $n++;
                // Check product in cart
                //$product = $modelProduct->start()->getDetail($item->id, null, $item->storeId);
                $product= $modelProduct->start()->getOldProductWithId($item->id);
                $product_photos = $modelProduct->start()->getOldProductPhotoDefault($product->storage_product_id);

                if(!$product) {
                continue;
                }
                // End check product in cart
                @endphp
                <tr class="row_cart form-group {{ session('arrErrorQty')[$product->storage_product_id] ?? '' }}{{ (session('arrErrorQty')[$product->storage_product_id] ?? 0) ? ' has-error' : '' }}">
                    <td>{{ $n }}</td>
                    <td>
                        <a href="#" class="row_cart-name">
                            @if ($product_photos)
                            @php
                            $old_url = config('app.old_url');
                            if (strpos($old_url, '//www.') !== false)
                            {
                            $old_url = str_replace("//www.", "//", $old_url);
                            }
                            @endphp
                            <img  width="100" src="{{ $old_url}}/uploads/products/{{ $product_photos->filename }}"  alt="{{ $product->title }}" />

                            @endif
                <!--                            <img width="100" src="{{ config('app.old_url')}}/{{ ($product->image) }}" alt="{{ $product->title }}"/>
                            -->
                        </a>
                        <span>
                            <a href="#" class="row_cart-name">{{ $product->title }}</a><br />

                        </span>

                    </td>

                    <td align="right">$@php
                        $productPrice = $modelProduct->showProductPrice($product->storage_product_id);
                        echo number_format((float)$productPrice, 2, '.', '');
                        $cost += $item->qty * $productPrice;
                        @endphp</td>
                    @php
                    $out_of_stock_status = $modelProduct->checkKeepOn($item->id);
                    if($out_of_stock_status==2){
                    $product_quantity=00;
                    }else{
                    $product_quantity = $modelProduct->checkQuantity($item->id);

                    }
                    //$product_quantity = $modelProduct->checkQuantity($item->id);
                    @endphp
                    <!-- Change the `data-field` of buttons and `name` of input field's for multiple plus minus buttons-->



                    <td class="cart-col-qty" style="width:150px;vertical-align: middle">
                        <div class="input-group plus-minus-input" style="margin-top:50px">
  <div class="input-group-button">
    <button type="button" id="minus" data-id="{{ $item->id }}"
                                   data-rowid="{{$item->rowId}}" data-store_id="0"  class="button hollow circle" data-quantity="minus" data-field="quantity">
      <i class="fa fa-minus" aria-hidden="true"></i>
    </button>
  </div>
  <input class="input-group-field"  style="height: 40px; margin: 0 auto;background:#fff;" type="number" name="quantity" min="1" value="{{$item->qty}}"
         data-id="{{ $item->id }}"  data-rowid="{{$item->rowId}}" data-store_id="0" id="qty_{{ $item->id }}" onInput="updateCart($(this));"   onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57">
  <div class="input-group-button">
      <button type="button" id="plus" data-id="{{ $item->id }}"
                                   data-rowid="{{$item->rowId}}" data-store_id="0" class="button hollow circle" data-quantity="plus" data-field="quantity">
      <i class="fa fa-plus" aria-hidden="true"></i>
    </button>
  </div>
</div>
                        <br/> <br/>
                        
                        
                        
                        
                        
<!--                        <div class="cart-qty" style="width:150px;vertical-align: middle">
                            <input style="width: 150px; margin: 0 auto;background:#fff;" type="number" data-id="{{ $item->id }}"
                                   data-rowid="{{$item->rowId}}" data-store_id="0" onchange="updateCart($(this));"
                                   class="item-qty form-control" min="1" name="qty-{{$item->id}}" value="{{$item->qty}}" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57">
                        </div>-->
                        <span class="text-danger item-qty-{{$item->id}}" style="display: none;"></span>
                        @if (session('arrErrorQty')[$product->storage_product_id] ?? 0)
                        <span class="help-block" id="item-qty-{{$item->id}}">
                            <br>
                            <!--                          {{ sc_language_render('cart.minimum_value', ['value' => session('arrErrorQty')[$product->storage_product_id]]) }}-->
                            {{ sc_language_render('Available  '.$product_quantity) }}
                        </span>
                        @elseif($product_quantity!=00 and $product_quantity < $item->qty )


                        <span class="help-block" id="item-qty-{{$item->id}}">

                            <br>{{ sc_language_render('Available  '.$product_quantity) }}
                        </span>
                        @endif
                    </td>

                    <td align="right" id="subtotalValue_{{$item->id}}">
                        $@php echo number_format($item->qty * $productPrice, 2);@endphp
                    </td>
            <input type="hidden" value="{{$productPrice}}" id="subtotal_{{$item->id}}"/>
            <input type="hidden" value="{{$item->qty * $productPrice}}" id="subtotalprice_{{$item->id}}"/>

            <td align="center">
                <a onClick="return confirm('Confirm?')" title="Remove Item" alt="Remove Item"
                   class="cart_quantity_delete"
                   href="{{ sc_route("cart.remove", ['id'=>$item->rowId, 'instance' => 'cart']) }}">
                    <i class="fa fa-times" aria-hidden="true"></i>
                </a>
            </td>
            </tr>

            @endforeach
            <tr class="row_cart form-group">
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td id="total" style="text-align:  right">$@php echo number_format($cost, 2);@endphp
                    <input type="hidden" value="{{$n}}" id="count"/>
                </td>
            <input type="hidden" value="{{$cost}}" id="cost"/>

            <td></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
@if(($product_quantity!=00 and $product_quantity < $item->qty) or (session('arrErrorQty')[$product->storage_product_id] ?? 0))
<div class="col-md-12 text-center" id="checkout" style="display:none" >
    <div class="pull-right">
        <button class="button button-lg button-secondary" type="submit">{{ sc_language_render('cart.checkout') }}</button>
    </div>
</div>
@else
<div class="col-md-12 text-center" id="checkout" >
    <div class="pull-right">
        <button class="button button-lg button-secondary" type="submit">{{ sc_language_render('cart.checkout') }}</button>
    </div>
</div>
@endif
@push('scripts')
<style>
   
.plus-minus-input {
  -webkit-align-items: center;
      -ms-flex-align: center;
          align-items: center;
}

.plus-minus-input .input-group-field {
  text-align: center;
  margin-left: 0.5rem;
  margin-right: 0.5rem;
  padding: 1rem;
}

.plus-minus-input .input-group-field::-webkit-inner-spin-button,
.plus-minus-input .input-group-field ::-webkit-outer-spin-button {
  -webkit-appearance: none;
          appearance: none;
}

.plus-minus-input .input-group-button .circle {
  padding: 0.25em 0.8em;
}

.stepper-arrow.up{
     display: none;
}
.stepper-arrow.down{
    display: none;
}
#plus{
    position: absolute;
    text-align: center;
    top: 2%;
   margin-left: -30px;
    width: 38px;
    height: 38px;
    font-size: 14px;
    line-height: 38px;
    font-weight: 400;
    font-family: "Material Design Icons";
    cursor: pointer;
    color: #151515;
    border-radius: 0;
    transition: .3s all ease;
        border-color: #ddd;

}
#minus{
    
    position: absolute;
    text-align: center;
    top: 2%;
   z-index: 99;
    width: 38px;
    height: 38px;
    font-size: 14px;
    line-height: 38px;
    font-weight: 400;
    font-family: "Material Design Icons";
    cursor: pointer;
    color: #151515;
    border-radius: 0;
    transition: .3s all ease;
    border-color: #ddd;

}
.stepper input[type="number"]{
    width: 117px;
}
svg:not(:root).svg-inline--fa {
    margin-bottom: 3px;
}
</style>
<script type="text/javascript">
    
    jQuery(document).ready(function(){
    // This button will increment the value
    $('[data-quantity="plus"]').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
       
        // Get its current value
     //   var currentVal = parseInt($('input[name='+fieldName+']').val());
         let id =  $(this).data('id');
        var     currentVal = document.getElementById('qty_' + id).value;
         fieldName = 'qty_' + id;
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
       currentVal = parseFloat(currentVal) + parseFloat(1);

           $('input[id='+fieldName+']').val(currentVal);
        } else {
            // Otherwise put a 0 there
            $('input[id='+fieldName+']').val(0);
        }
             let obj=$(this);
              updateCart(obj);
    });
    // This button will decrement the value till 0
    $('[data-quantity="minus"]').click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
      //  fieldName = $(this).attr('data-field');
         let id =  $(this).data('id');
        var     currentVal = document.getElementById('qty_' + id).value;
       fieldName = 'qty_' + id;
        // Get its current value
      //  var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
         currentVal = parseFloat(currentVal) - parseFloat(1);

            $('input[id='+fieldName+']').val(currentVal);
        } else {
            // Otherwise put a 0 there
            $('input[id='+fieldName+']').val(0);
        }
        
             let obj=$(this);
              updateCart(obj);
    });
});


    function updateCart(obj) {
        //    $('#test').change(function(obj) {
       
        let storeId = obj.data('store_id');
        let rowid = obj.data('rowid');
        let id = obj.data('id');
        var i;
        var count;
        var total;
        var new_qty;
       new_qty = document.getElementById('qty_' + id).value;

        //  fieldName = 'quantity';
        // Get its current value
        //  alert(obj.val());
    //    var new_qty = parseInt($('input[name='+fieldName+']').val());
       
     
        $.ajax({
            url: '{{ sc_route('cart.update') }}',
            type: 'POST',
            dataType: 'json',
            async: false,
            cache: false,
            data: {
                id: id,
                rowId: rowid,
                new_qty: new_qty,
                storeId: storeId,
                _token: '{{ csrf_token() }}'},
            success: function (data) {
                error = parseInt(data.error);

                if (error === 0)
                {

                    //   count= document.getElementById('count').value;
                    let       cost = document.getElementById('cost').value;
                    let       price = document.getElementById('subtotal_' + id).value;
                    let       subtotalPrice = document.getElementById('subtotalprice_' + id).value;
                    let  newTotal = new_qty * price;
                    newTotal = parseFloat(newTotal).toFixed(2);
                    total = parseFloat(cost) - parseFloat(subtotalPrice);
                    total = parseFloat(newTotal) + parseFloat(total);
                     allTotal = parseFloat(total).toFixed(2);
                    //    for(i=1;i<=count;i++){
                    document.getElementById('subtotalValue_' + id).innerText = "$" + newTotal;

                    //     } 
                 //   alert(allTotal);
                   //   alert(totalx);

                    //  window.location.replace(location.href);
                    document.getElementById('cost').value=allTotal;                   
                    document.getElementById('subtotalprice_' + id).value=newTotal;
                    document.getElementById('total').innerText = "$" + allTotal;
                     document.getElementById('checkout').style.display = "block";
                    $('.item-qty-' + id).css('display', 'none').html(data.msg);
                    $('#item-qty-' + id).css('display', 'none').html(data.msg);
                } else {

                    $('.item-qty-' + id).css('display', 'block').html(data.msg);
                    if (data.msg.includes("Available")) {
                        document.getElementById('checkout').style.display = "none";
                    }




                }
            }
        });

    }

    function buttonQty(obj, action) {
        var parent = obj.parent();
        var input = parent.find(".item-qty");
        if (action === 'reduce') {
            input.val(parseInt(input.val()) - 1);
        } else {
            input.val(parseInt(input.val()) + 1);
        }
        updateCart(input);
    }
</script>
@endpush
<style>
    .stepper-arrow.up {
        background: #e5dfdf !important;
    }
    .stepper-arrow.down {
        background: #e5dfdf !important;
    }
</style>