@php
$productsNew = $modelProduct->start()->getOldProductsListDetails($product->id);
$checkProductOption = $modelProduct->start()->checkProductsOptions($product->id);
$product_photos = $modelProduct->start()->getOldProductPhotoDefault($productsNew[0]->storage_product_id);
 $stock_status= $modelProduct->getStockStatus($productsNew[0]->storage_product_id);
@endphp
<div style="display: none;" id="getImage">
</div>
<article class="product wow fadeInRight">
    <div class="product-body">
        <div class="product-figure">

            <a href="{{ sc_route('product.detail', ['alias' => $product->id]);}}">
            <!--          <img src="{{ config('app.old_url')}}/{{ $modelProduct->getOldThumb($productsNew[0]->image) }}" alt="{{ $product->title }}"/>-->
 
                @if ($product_photos)
                @php
                $old_url = config('app.old_url');
                if (strpos($old_url, '//www.') !== false)
                {
                $old_url = str_replace("//www.", "//", $old_url);
                }
                @endphp
                <img  src="{{ $old_url}}/uploads/products/{{ $product_photos->filename }}"  style="height: 190px;" />

                @else
                <img  src="{{config('app.url')}}/{{ sc_store('logo', ($storeId ?? null)) }}" alt="" style="height: 190px;"/></a>

            @endif

            </a>
        </div>
        <h5 class="product-title"><a href="{{ sc_route('product.detail', ['alias' => $product->id]);}}">{{ $product->title }}</a></h5>
        <input style=" min-height: 35px !important; background-color: #fff !important;width: 55px;margin: 0 auto;" class="form-input" id="qty_{{$product->id}}" name="qty" type="number" data-zeros="true" value="1" min="1" max="100">

        @if(count($checkProductOption)== 0)
        @php
        $productPrice = $modelProduct->showProductPrice($productsNew[0]->storage_product_id);
        @endphp

        <input type="hidden" name="" value="{{$productPrice}}" id='price'/>
        @if($stock_status=="")
        @if($productPrice === "Price For Member Only"  )
        <a href="{{sc_route('login')}}" class="add-to-cart-list">
            <i class="fa fa-cart-plus fa-2x"></i> </a>
        <br />  <div class="product-price">
            {{$productPrice}}
            @else
            <a onClick="addToCartAjax('{{ $productsNew[0]->storage_product_id }}', 'default', '', document.getElementById('qty_' +<?php echo $product->id ?>).value)" class="add-to-cart-list">
                <i class="fa fa-cart-plus fa-2x"></i> </a>
            <br />  <div class="product-price">
                $ @php echo number_format((float)$productPrice, 2, '.', '')@endphp 

                @endif
                @else
                <div class="product-price">
                    @if($productPrice === "Price For Member Only"  )
                    @else
                    $
                    @endif
                    @php echo number_format((float)$productPrice, 2, '.', '')@endphp 
                    @endif
                </div>
                @else
                <div id="demox"></div>
                <a  style="display:none;" id="cart_{{$product->id}}" onClick="addToCartAjax(document.getElementById('storage_id').value, 'default', '', document.getElementById('qty_' +<?php echo $product->id ?>).value)" class="add-to-cart-list">
                    <i class="fa fa-cart-plus fa-2x"></i> </a>
                <a style="display:none;" id="cartx_{{$product->id}}" href="{{sc_route('login')}}" class="add-to-cart-list">
                    <i class="fa fa-cart-plus fa-2x"></i> </a>
                    <div style="margin-left: 105px;">
                <div class="product-price" id="productPrice_{{$product->id}}"> </div>
                
                <div style="display:none;"  class="product-price" id="productPrice2">
                </div>
                                   </div>

              <br/>
                <input type="hidden" name="storage_id" value="" id='storage_id'/>
                  <div class="product-price-wrap">
                    <div class="product-price" id="p_price_{{$product->id}}">
                        @php
                        $productPrice=array();
                        foreach($checkProductOption as $check){
                        $productPrice[]= $modelProduct->showProductPrice($check->storage_product_id);

                        }
                        if(($productPrice[0]=="Price For Member Only" or $productPrice[1]=="Price For Member Only") AND !(auth()->user())){
                        echo 'Price For Member Only';
                        }else{
                        echo '  <div style="margin-left: 105px;">';
                        if(min($productPrice)== max($productPrice))
                        {
                        $productPrice=  min($productPrice);
                        $productPrice=  number_format((float)$productPrice, 2, '.', '');
                        echo "$ ".$productPrice;
                        }else{
                        $productPriceMin=  min($productPrice);
                        $productPriceMin=  number_format((float)$productPriceMin, 2, '.', '');
                        $productPriceMax=  max($productPrice);
                        $productPriceMax=  number_format((float)$productPriceMax, 2, '.', '');


                        echo   "$ ".$productPriceMin.' - ';
                        echo  $productPriceMax;
                        }
                        echo '  </div>';
                        }
                        @endphp

                    </div>
                </div>
                <select name="product_option" id="product_option" onchange="addCart(this.value,{{$product->id}})" style="margin-top:5px;">
                    <option value="">Select Option</option>
                    @foreach($checkProductOption as $option)
                    <option value="{{$option->storage_product_id}}">{{$option->title}}</option>
                    @endforeach
                </select><br/>

              
                @endif



            </div>

            <span id="stock_status">

                @php  echo $stock_status; @endphp

            </span>

            <div class="product-button-wrap">
              
            </div>
            </article>
            <div id="cartd"></div>
            <script type="text/javascript">
                function addCart(show, xx){
                var x = show;
                var productPrice = 0;
                var price = 0;
                var stock_status;
                //alert('#cart_'+xx);
                price = document.getElementById('price').value;
                document.getElementById('cartd').style.display = "block";
               
                var id = show;
                var cart = document.getElementById('cart_' + xx);
                var cartx = document.getElementById('cartx_' + xx);
                //var productPrice = document.getElementById('productPrice_'+xx);
                //alert(xx);
                $.ajax({
                url:'{{ sc_route("product.price") }}',
                        type:'get',
                        dataType:'text',
                        data:{id:id},
                        beforeSend: function(){
                        $('#loading').show();
                        },
                        success: function(result){
                        //     console.log(data);
                        // check price and image
                        const myArr = result.split("/");
                        //alert(myArr[0]);
                    <?php 
                    $old_url = config('app.old_url');
                        if (strpos($old_url, '//www.') !== false)
                        {
                            $old_url = str_replace("//www.", "//", $old_url);
                        }
                    ?>
                        if (result.indexOf("Out of Stock") > - 1) {
                        document.getElementById('productPrice2').innerText = "Out Of stock";
                        document.getElementById('getImage').innerHTML = '<img class="xzoom" id="xzoom-default" src="{{ $old_url}}/uploads/products/' + myArr[1] + '" xoriginal="{{ $old_url }}/uploads/products/' + myArr[1] + '"   />';
                        document.getElementById('productPrice_' + xx).innerText = "Out Of stock";
                        document.getElementById('p_price_' + xx).style.display = "none";
                        cart.style.display = "none";
                        cartx.style.display = "none";
                        } else{                          
                        myArr[0] = parseFloat(myArr[0]).toFixed(2);
                        document.getElementById('productPrice2').innerText = "$" + myArr[0];
                       // document.getElementById('p_price_' + xx).style.display = "none";
                        document.getElementById('getImage').innerHTML = '<img class="xzoom" id="xzoom-default" src="{{ $old_url}}/uploads/products/' + myArr[1] + '" xoriginal="{{ $old_url}}/uploads/products/' + myArr[1] + '"   />';
                        if (myArr[0].indexOf("Price For Member Only") > - 1){
                        //document.getElementById('productPrice_'+xx).innerText= myArr[0];

                        } else{
                        myArr[0] = parseFloat(myArr[0]).toFixed(2);
                        document.getElementById('productPrice_' + xx).innerText = "$" + myArr[0];
                        document.getElementById('p_price_'+ xx).style.display = "none";
                        }



                        if (price == "Price For Member Only"){
                       // cartx.style.display = "block";
                        $("#cartx_"+xx).show();
                        } else{
                      //  cart.style.display = "block";
                        $("#cart_"+xx).show();

                        }
                        }

                        // myArr = data.split("-");
                        //alert(myArr);

                        if (result.error == 0) {
                        location.reload();
                        }
                        }
                });
               
                document.getElementById('storage_id').value = show;
                document.getElementById('product-detail-id').value = show;
                // document.getElementById('product-price').innerText="$"+ productPrice;

                }

            </script>
            <style>
                .stepper {

                    width:118px;
                    float:left;
                    margin-top: 11px;
                    background:#e5dfdf;
                }

                .stepper-arrow.down {
                    left: -5px;
                }
                .add-to-cart-list{
                    font-size: 20px !important;
                    color: #000;
                    cursor: pointer; 
                }
                select{
                    width:180px !important;
                }
            </style>

