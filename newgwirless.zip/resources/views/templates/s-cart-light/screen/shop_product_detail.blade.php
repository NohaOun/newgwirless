@php
/*
$layout_page = shop_product_detail
**Variables:**
- $product: no paginate
- $productRelation: no paginate
*/
@endphp

@extends($sc_templatePath.'.layout')

{{-- block_main --}}
@section('block_main')
@php
    $countItem = 0;
       $checkProductOption = $modelProduct->start()->checkProductsOptions($product->product_id);  
       $product_photos = $modelProduct->start()->getOldProductPhotoDefault($product->storage_product_id);
     //  print_r($product_photos); 
       $old_url = config('app.old_url');
                        if (strpos($old_url, '//www.') !== false)
                        {
                            $old_url = str_replace("//www.", "//", $old_url);
                        }
@endphp
      <!-- Single Product-->
      <section class="section section-sm section-first bg-default">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-6">
              <div class="slick-vertical slick-product">
                   <section id="default" class="padding-top0">
    <div class="row">
      <div class="large-5 column">
          <div class="xzoom-container" id="getImage">              
            @if ($product_photos)
             <img class="xzoom" id="xzoom-default" src="{{ $old_url}}/uploads/products/{{ $product_photos->filename }}" xoriginal="{{$old_url}}/uploads/products/{{ $product_photos->filename }}" />
         
             @else
          <img  src="{{ sc_file(sc_store('logo', ($storeId ?? null))) }}" alt="" style="height: 190px;"/></a>

            @endif

         
        </div>        
      </div>
      <div class="large-7 column"></div>
    </div>
    </section>
              
  <div class="large-7 column"></div>
              </div>
            </div>
            <div class="col-lg-6">
            <form id="buy_block" class="product-information" action="{{ sc_route('cart.add') }}" method="post">
              {{ csrf_field() }}
              <input type="hidden" name="storeId" id="product-detail-storeId" value="0" />
              <div class="single-product">
                <h3 class="text-transform-none font-weight-medium" id="product-detail-name">{{ $name }}</h3>
                
               
                <p>
                  SKU: <span id="product-detail-model">{{ $product->sku }}</span>
                </p>

                {{-- Show price --}}
                <div class="group-md group-middle">
                  <div class="single-product-price" id="product-detail-price">
                          @if(count($checkProductOption)== 0)
                             @php
                            $productPrice = $modelProduct->showProductPrice($product->storage_product_id);
                           @endphp
                           
                            @if($productPrice == "Price For Member Only" AND !(auth()->user()))
                            {{$productPrice}}
                            @else
                            $ @php echo number_format((float)$productPrice, 2, '.', '')@endphp
                           @endif
                           @else
                           @php
    foreach($checkProductOption as $check){
     $productPrice[]= $modelProduct->showProductPrice($check->storage_product_id);

    }
  
  if(($productPrice[0]=="Price For Member Only" or $productPrice[1]=="Price For Member Only") AND !(auth()->user())){
  echo 'Price For Member Only';
  }else{
 $productPriceMin=  min($productPrice);
   $productPriceMin=  number_format((float)$productPriceMin, 2, '.', '');
    $productPriceMax=  max($productPrice);
      $productPriceMax=  number_format((float)$productPriceMax, 2, '.', '');
            echo   "$ ".$productPriceMin.' - ';
         echo  $productPriceMax;

  }
    @endphp
                           @endif
                    

                  </div>
                </div>
                {{--// Show price --}}

                <hr class="hr-gray-100">

                {{-- Button add to cart --}}
                @if ($modelProduct->checkProductQuantity($product->id))
                  @if($productPrice =="Price For Member Only" AND !(auth()->user()))
                   <div>
                        <a href="{{sc_route('login')}}" class="button button-lg button-secondary button-zakaria">{{ sc_language_render('action.add_to_cart') }}</a>
                    </div>
@else
                    @if(count($checkProductOption)== 0)
                <input type="hidden" name="product_id" id="product-detail-id" value="{{ $product->storage_product_id }}" />

                <div class="group-xs group-middle">
                    <div class="product-stepper">
                      <input class="form-input" name="qty" type="number" data-zeros="true" value="1" min="1" max="100">
                    </div>
                    <div>
                        <button class="button button-lg button-secondary button-zakaria" type="submit">{{ sc_language_render('action.add_to_cart') }}</button>
                    </div>
                </div>
                 @else
                  <div style="display:none;" id="cartd" class="group-middle">
                      <div class="product-stepper" >
                      <input class="form-input" name="qty" type="number" data-zeros="true" value="1" min="1" max="100">
                      <input type="hidden" name="storage_id" value="" id='storage_id'/>
                      <input type="hidden" name="product_id" class="storage_id" id="product-detail-id" value="" />

                      </div> 
                      <div >
                        <button style="margin-left:20px;margin-top:10px" class="button button-lg button-secondary button-zakaria" type="submit">{{ sc_language_render('action.add_to_cart') }}</button>
                    </div>
                </div>
                 <br/>
                  <div id="product-detail-attr">
                 <select name="product_option" id="product_option" onchange="addCart(this.value)">
         <option value="">Select Option</option>
        @foreach($checkProductOption as $option)
        <option value="{{$option->storage_product_id}}">{{$option->title}}</option>
        @endforeach
                 </select> &nbsp;&nbsp;
              <div class="single-product-price" id="productPrice2">
                                        </div>
                  </div>
                @endif
                @endif
                 @endif
                {{--// Button add to cart --}}

                {{-- Show attribute --}}
                @if (sc_config('product_property'))
              
                @endif
                {{--// Show attribute --}}

                {{-- Stock info --}}
                @if (sc_config('product_stock'))
                <div>
<!--                    {{ sc_language_render('product.stock_status') }}:-->
                    <span id="stock_status">
               
                 @php  echo $modelProduct->getStockStatus($product->storage_product_id); @endphp
                           
                    </span> 
                </div>
                @endif
                {{--// Stock info --}}

              <div class="product-price-wrap" style="display: none;">
      <div class="product-price" id="p_price_{{$product->id}}">
          
      </div>
      </div>

                
             

<!--              
                <hr class="hr-gray-100">-->

                {{-- Social --}}
<!--                <div class="group-xs group-middle"><span class="list-social-title">Share</span>
                  <div>
                    <ul class="list-inline list-social list-inline-sm">
                      <li><a class="icon mdi mdi-facebook" href="#"></a></li>
                      <li><a class="icon mdi mdi-twitter" href="#"></a></li>
                      <li><a class="icon mdi mdi-instagram" href="#"></a></li>
                      <li><a class="icon mdi mdi-google-plus" href="#"></a></li>
                    </ul>
                  </div>
                </div>-->
                {{--// Social --}}

              </div>
            </form>
            </div>
          </div>

          <!-- Bootstrap tabs-->
          <div class="tabs-custom tabs-horizontal tabs-line" id="tabs-1">
            <!-- Nav tabs-->
            <div class="nav-tabs-wrap">
              <ul class="nav nav-tabs nav-tabs-1">
                <li class="nav-item" role="presentation">
                  <a class="nav-link active" href="#tabs-1-1" data-toggle="tab">{{ sc_language_render('product.description') }}</a>
                </li>
              </ul>
            </div>

            {{-- Render connetnt --}}
            <div class="tab-content tab-content-1">
              <div class="tab-pane fade show active" id="tabs-1-1">
                {!! sc_html_render($product->pro_details) !!}
              </div>
            </div>
            {{--// Render connetnt --}}

          </div>
        </div>
      </section>


      @if ($productRelation->count())
      <!-- Related Products-->
      <section class="section section-sm section-last bg-default">
        <div class="container">
          <h4 class="font-weight-sbold">{{ sc_language_render('front.products_recommend') }}</h4>
          <div class="row row-lg row-30 row-lg-50 justify-content-center">
            @foreach ($productRelation as $key => $productRel)
            <div class="col-sm-6 col-md-5 col-lg-3">
                  {{-- Render product single --}}
                  @include($sc_templatePath.'.common.product_single_old', ['product' => $productRel])
                  {{-- //Render product single --}}
            </div>
            @endforeach
          </div>
        </div>
      </section>
      @endif
      
   {{-- Render include view --}}
   @include($sc_templatePath.'.common.include_view')
   {{--// Render include view --}}
           <input type="hidden" name="" value="00" id='price'/>
           

<!--/product-details-->
@endsection
{{-- block_main --}}


@push('styles')
{{-- Your css style --.stepper-arrow.up {
    


}}

@endpush
<script type="text/javascript">
function addCart(show){
   document.getElementById('cartd').style.display = "block";    
   document.getElementById('product-detail-id').value = show; 
  // document.getElementById('productPrice_3').innerText="$";
    
}

</script>

@push('scripts')
{{-- //script here --}}
@endpush
 