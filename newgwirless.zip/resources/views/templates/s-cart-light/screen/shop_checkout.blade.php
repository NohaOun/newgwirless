@php
/*
$layout_page = shop_checkout
**Variables:**
- $cartItem: collection
- $storeCheckout: int
- $shippingMethod: string
- $paymentMethod: string
- $totalMethod: array
- $dataTotal: array
- $shippingAddress: array
- $countries: array
- $attributesGroup: array
*/
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-xl bg-default text-md-left">
    <div class="container">
        <div class="row">
            @if (count($cartItem) ==0)
            <div class="col-md-12 text-danger min-height-37vh">
                {!! sc_language_render('cart.cart_empty') !!}!
            </div>
            @else
          

            {{-- Item cart detail --}}
         {{--     @include($sc_templatePath.'.common.cart_list', ['cartItem' => $cartItem])--}}
            {{-- //Item cart detail --}}


            <div class="col-md-12">
            <form class="sc-shipping-address" id="form-process" role="form" method="POST" action="{{ sc_route('checkout.process') }}">
                @csrf
                <div class="row">
                    {{-- Begin address shipping --}}
                    <div class="col-md-6">
                        {{-- Select address if customer login --}}
                      <div
                                            class="form-group {{ $errors->has('shippingMethod') ? ' has-error' : '' }}">
                        <h3 class="control-label"><i class="fa fa-shopping-bag" aria-hidden="true"></i>Ship To:<br></h3>
                                          
                                        </div>
                        {{--// Select address if customer login --}}
                        
                        {{-- Render address shipping --}}
                        <table class="table table-borderless table-responsive">
                           @if (sc_config('customer_address1'))
                            <tr>
                                    <td 
                                        class="form-group {{ $errors->has('address1') ? ' has-error' : '' }}">
                                        <label for="address1" class="control-label"><i class="fa fa-list-ul"></i>
                                            {{ sc_language_render('order.address') }}:</label>
                                        <input class="form-control" name="address1" type="text" placeholder="{{ sc_language_render('order.address1') }}"
                                            value="{{ old('address1',$shippingAddress['address1'])}}">
                                        @if($errors->has('address1'))
                                            <span class="help-block">{{ $errors->first('address1') }}</span>
                                        @endif
                                    </td>
                                      <td 
                                        class="form-group {{ $errors->has('city') ? ' has-error' : '' }}">
                                        <label for="address1" class="control-label"><i class="fa fa-list-ul"></i>
                                            {{ sc_language_render('City') }}:</label>
                                        <input class="form-control" name="city" type="text" placeholder="{{ sc_language_render('city') }}"
                                            value="{{ old('city',$shippingAddress['city'])}}">
                                        @if($errors->has('city'))
                                            <span class="help-block">{{ $errors->first('city') }}</span>
                                        @endif
                                    </td>
                            </tr>
                            @endif

                           
                            @if (sc_config('customer_country'))
                            <tr>
                                <td  class="form-group{{ $errors->has('country') ? ' has-error' : '' }}">
                                    <label for="country" class="control-label"><i class="fas fa-globe"></i>
                                        {{ sc_language_render('State') }}:</label>
                                    @php
                                        $ct = old('country',$shippingAddress['country']);
                                    @endphp
                                    <select class="form-control country " style="width: 100%;" name="country">
                                        <option value="">__{{ sc_language_render('state') }}__</option>
                                        @foreach ($countries as $k => $v)
                                        <option value="{{ $k }}" {{ ($ct ==$k) ? 'selected':'' }}>{{ $v }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('country'))
                                        <span class="help-block">
                                            {{ $errors->first('country') }}
                                        </span>
                                    @endif
                                </td>
                                  @if (sc_config('customer_postcode'))
                                    <td class="form-group {{ $errors->has('postcode') ? ' has-error' : '' }}">
                                        <label for="postcode" class="control-label"><i class="fa fa-tablet"></i>
                                            {{ sc_language_render('Zip') }}:</label>
                                        <input class="form-control" name="postcode" type="text" placeholder="{{ sc_language_render('order.postcode') }}"
                                            value="{{ old('postcode',$shippingAddress['postcode'])}}">
                                        @if($errors->has('postcode'))
                                            <span class="help-block">{{ $errors->first('postcode') }}</span>
                                        @endif
                                    </td>
                                @endif

                            </tr>
                            @endif

                               <tr>
                                <td colspan="2">
                                    <label class="control-label"><i class="fa fa-calendar-o"></i>
                                        {{ sc_language_render('cart.note') }}:</label>
                                    <textarea class="form-control" rows="5" name="comment"
                                        placeholder="{{ sc_language_render('cart.note') }}....">{{ old('comment','')}}</textarea>
                                </td>
                            </tr>


                        

                          
                        </table>
                        {{-- //Render address shipping --}}
                      
                    </div>
                    {{--// End address shipping --}}

@if (!sc_config('shipping_off'))
                                {{-- Shipping method --}}
                                <div class="row">
                                    <div class="col-md-12">
                                        <div
                                            class="form-group {{ $errors->has('shippingMethod') ? ' has-error' : '' }}">
                                            <h3 class="control-label"><i class="fa fa-truck" aria-hidden="true"></i>
                                                {{ sc_language_render('order.shipping_method') }}:<br></h3>
                                            @if($errors->has('shippingMethod'))
                                            <span class="help-block">{{ $errors->first('shippingMethod') }}</span>
                                            @endif
                                        </div>

                                        <div class="form-group">
<!--                                    <label class="radio-inline">
                                     <input type="radio" name="shippingMethod" onchange="addShipping('0')"
                                                        value="0" 
                                                        style="position: relative;"
                                                       />
                                                    Free Shipping (curbside pickup)  $0
                                                </label>-->
                                            @foreach ($shippingMethod as $key => $shipping)
                                            @php  $shipping['value']=number_format((float)$shipping['value'], 2, '.', ''); @endphp
                                            <div>
                                                <label class="radio-inline">
                                                    <input type="radio" name="shippingMethod" onchange="addShipping({{ $shipping['value'] }})"
                                                        value="{{ $shipping['key'] }}"
                                                        {{ (old('shippingMethod') == $key)?'checked':'' }}
                                                        style="position: relative;"
                                                        {{ ($shipping['permission'])?'':'disabled' }}>
                                                    @if($shipping['title']=='Shipping Free')
                                                   {{ $shipping['title'] }} (pick up)
                                                    @else
                                                    {{ $shipping['title'] }}
                                                    @endif
                                                      ${{ $shipping['value'] }}
                                                </label>
                                            </div>

                                            {{-- Render view --}}
                                            @includeIf($shipping['pathPlugin'].'::render')
                                            {{-- //Render view --}}

                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                {{-- //Shipping method --}}
@endif
                    <div class="col-md-6">
                        {{-- Total --}}
                        <div class="row">
                            <div class="col-md-12">
                                {{-- Data total --}}
                                @include($sc_templatePath.'.common.render_total')
                                {{-- Data total --}}

                                {{-- Total method --}}
                                <div class="row">
                                    <div class="col-md-12">
                                        <div
                                            class="form-group {{ $errors->has('totalMethod') ? ' has-error' : '' }}">
                                            @if($errors->has('totalMethod'))
                                                <span class="help-block">{{ $errors->first('totalMethod') }}</span>
                                            @endif
                                        </div>

                                        <div class="form-group">
                                            @foreach ($totalMethod as $key => $plugin)
                                                @includeIf($plugin['pathPlugin'].'::render')
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                {{-- //Total method --}}

  @if (!sc_config('payment_off'))
                                {{-- Payment method --}}
                                <div class="row">
                                    <div class="col-md-12">
                                        <div
                                            class="form-group {{ $errors->has('paymentMethod') ? ' has-error' : '' }}">
                                            <h3 class="control-label"><i class="fa fa-credit-card-alt"></i>
                                                {{ sc_language_render('order.payment_method') }}:<br></h3>
                                            @if($errors->has('paymentMethod'))
                                            <span class="help-block">{{ $errors->first('paymentMethod') }}</span>
                                            @endif
                                        </div>
                                        <div class="form-group cart-payment-method">
                                            @foreach ($paymentMethod as $key => $payment)
                                            <div>
                                                <label class="radio-inline">
                                                    <input type="radio" name="paymentMethod"
                                                        value="{{ $payment['key'] }}"
                                                        {{ (old('shippingMethod') == $key)?'checked':'' }}
                                                        style="position: relative;"
                                                        {{ ($payment['permission'])?'':'disabled' }}>
                                                        <label class="radio-inline" for="payment-{{ $payment['key'] }}">
                                                            <img width="100" title="{{ $payment['title'] }}"
                                                                alt="{{ $payment['title'] }}"
                                                                src="{{ sc_file($payment['image']) }}">
                                                        </label>
                                                </label>
                                            </div>

                                            {{-- Render view --}}
                                            @includeIf($payment['pathPlugin'].'::render')
                                            {{-- //Render view --}}

                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                {{-- //Payment method --}}
@endif

                            </div>
                            
                        </div>
                        {{-- End total --}}

                        {{-- Button checkout --}}
                        <div class="row" style="padding-bottom: 20px;">
                            <div class="col-md-12 text-center">
                                <div class="pull-right">
                                    {!! $viewCaptcha ?? ''!!}
                                    <button class="button button-lg button-secondary" type="submit" id="button-form-process">{{ sc_language_render('cart.checkout') }}</button>
                                </div>
                            </div>
                        </div>
                        {{-- Button checkout --}}

                    </div>
               
                
                </div>
            </form>
        </div>





            @endif
        </div>
    </div>
</section>

   {{-- Render include view --}}
   @include($sc_templatePath.'.common.include_view')
   {{--// Render include view --}}

@endsection




@push('scripts')

{{-- Render script from total method --}}
@foreach ($totalMethod as $key => $plugin)
    @includeIf($plugin['pathPlugin'].'::script')
@endforeach
{{--// Render script from total method --}}

{{-- Render script from shipping method --}}
@foreach ($shippingMethod as $key => $plugin)
    @includeIf($plugin['pathPlugin'].'::script')
@endforeach
{{--// Render script from shipping method --}}

{{-- Render script from payment method --}}
@foreach ($paymentMethod as $key => $plugin)
    @includeIf($plugin['pathPlugin'].'::script')
@endforeach
{{--// Render script from payment method --}}

<script type="text/javascript">

    function addShipping(value){
      value= parseFloat(value).toFixed(2);
     document.getElementById('getShipping').innerHTML='<th>Shipping</th><td style="text-align: right" id="shipping">$'+value+'</td>';
        $("#getShipping").show();
         oldTotal= document.getElementById('oldTotal').value;
         total= parseFloat(value)+ parseFloat(oldTotal);
          total= parseFloat(total).toFixed(2);
          document.getElementById('newTotal').value='$'+total;


    }
    $('#button-form-process').click(function(){
        $('#form-process').submit();
        $(this).prop('disabled',true);
    });

    $('#addressList').change(function(){
        var id = $('#addressList').val();
        if(!id) {
            return;   
        } else if(id == 'new') {
            $('#form-process [name="first_name"]').val('');
            $('#form-process [name="last_name"]').val('');
            $('#form-process [name="phone"]').val('');
            $('#form-process [name="postcode"]').val('');
            $('#form-process [name="company"]').val('');
            $('#form-process [name="country"]').val('');
            $('#form-process [name="address1"]').val('');
            $('#form-process [name="address2"]').val('');
            $('#form-process [name="address3"]').val('');
        } else {
            $.ajax({
            url: '{{ sc_route('customer.address_detail') }}',
            type: 'GET',
            dataType: 'json',
            async: false,
            cache: false,
            data: {
                id: id,
            },
            success: function(data){
                error= parseInt(data.error);
                if(error === 1)
                {
                    alert(data.msg);
                }else{
                    $('#form-process [name="first_name"]').val(data.first_name);
                    $('#form-process [name="last_name"]').val(data.last_name);
                    $('#form-process [name="phone"]').val(data.phone);
                    $('#form-process [name="postcode"]').val(data.postcode);
                    $('#form-process [name="company"]').val(data.company);
                    $('#form-process [name="country"]').val(data.country);
                    $('#form-process [name="address1"]').val(data.address1);
                    $('#form-process [name="address2"]').val(data.address2);
                    $('#form-process [name="address3"]').val(data.address3);
                }

                }
        });
        }
    });
   

</script>

@endpush

@push('styles')
{{-- Your css style --}}
@endpush
<style>
    h3, .heading-3, .event-classic-date{
        font-size:22px !important;
    }
    .help-block {
    font-size: 14px !important;
    font-weight: bold;
}
    </style>