@php
/*
$layout_page = shop_product_detail
**Variables:**
- $product: no paginate
- $productRelation: no paginate
*/
@endphp

@extends($sc_templatePath.'.layout')

{{-- block_main --}}
@section('block_main')
@php
    $countItem = 0;
       $checkProductOption = $modelProduct->start()->checkProductsOptions($product->product_id);  
@endphp
      <!-- Single Product-->
      <section class="section section-sm section-first bg-default">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-6">
              <div class="slick-vertical slick-product">
                   <section id="default" class="padding-top0">
    <div class="row">
      <div class="large-5 column">
        <div class="xzoom-container">
          <img class="xzoom" id="xzoom-default" src="{{ config('app.old_url')}}/{{ $product->image }}" xoriginal="{{ config('app.old_url')}}/{{ $product->image }}" />
          <div class="xzoom-thumbs">
               @if ($product_photos->count())
                  @php
                    $countItem = 1 + $product_photos->count();
                     @endphp
                  @foreach ($product_photos as $key=>$image)
                <a href="{{ config('app.old_url')}}/uploads/products/{{ $image->filename }}"><img class="xzoom-gallery" width="80" src="{{ config('app.old_url')}}/uploads/products/{{ $image->filename }}" ></a>

                  @endforeach
                  @endif
            </div>
        </div>        
      </div>
      <div class="large-7 column"></div>
    </div>
    </section>
                <!-- Slick Carousel-->
                <div class="slick-slider carousel-parent" id="carousel-parent" data-items="1" data-swipe="true" data-child="#child-carousel" data-for="#child-carousel">
                  <div class="item">
                    <div class="slick-product-figure"><img src="{{ config('app.old_url')}}/{{ $product->image }}" alt="" width="530" height="480"/>
                    </div>
                  </div>
                  @if ($product_photos->count())
                  @php
                    $countItem = 1 + $product_photos->count();
                     @endphp
                  @foreach ($product_photos as $key=>$image)
                  <div class="item">
                      <div class="slick-product-figure"><img src="{{ config('app.old_url')}}/uploads/products/{{ $image->filename }}" class="xzoom" alt="" width="530" height="480"/>
                    </div>
                  </div>
                  @endforeach
                  @endif
                </div>

                @if ($countItem > 1)
                <div class="slick-slider child-carousel slick-nav-1" id="child-carousel" data-arrows="true" data-items="{{ $countItem }}" data-sm-items="{{ $countItem }}" data-md-items="{{ $countItem }}" data-lg-items="{{ $countItem }}" data-xl-items="{{ $countItem }}" data-xxl-items="{{ $countItem }}" data-md-vertical="true" data-for="#carousel-parent">
                    <div class="item xzoom-thumbs">
                      <div class="slick-product-figure"><img src="{{ config('app.old_url')}}/{{ $product->image }}" alt="" width="530" height="480"/>
                      </div>
                    </div>
                    @foreach ($product_photos as $key=>$image)
                    <div class="item">
                      <div class="slick-product-figure"><img src="{{ config('app.old_url')}}/uploads/products/{{ $image->filename }}" alt="" width="530" height="480"/>
                      </div>
                    </div>
                    @endforeach
                  </div>
                @endif
  <div class="large-7 column"></div>
              </div>
            </div>
            <div class="col-lg-6">
            <form id="buy_block" class="product-information" action="{{ sc_route('cart.add') }}" method="post">
              {{ csrf_field() }}
              <input type="hidden" name="storeId" id="product-detail-storeId" value="0" />
              <div class="single-product">
                <h3 class="text-transform-none font-weight-medium" id="product-detail-name">{{ $name }}</h3>
                
               
                <p>
                  SKU: <span id="product-detail-model">{{ $product->sku }}</span>
                </p>

                {{-- Show price --}}
                <div class="group-md group-middle">
                  <div class="single-product-price" id="product-detail-price">
                          @if(count($checkProductOption)== 0)
                             @php
                             $productPrice = $modelProduct->showProductPrice($product->storage_product_id);
                           @endphp
                            @if($productPrice =="Price For Member Only")
                            {{$productPrice}}
                           @endif
                           @else
                           $
                           @php
    foreach($checkProductOption as $check){
     $productPrice[]= $modelProduct->showProductPrice($check->storage_product_id);

    }
  
  echo   $min = min($productPrice).' - ';
  echo  $max = max($productPrice);
    @endphp
                           @endif
                    

                  </div>
                </div>
                {{--// Show price --}}

                <hr class="hr-gray-100">

                {{-- Button add to cart --}}
                @if ($modelProduct->checkProductQuantity($product->id))
                  @if($productPrice =="Price For Member Only")
                   <div>
                        <a href="{{sc_route('login')}}" class="button button-lg button-secondary button-zakaria">{{ sc_language_render('action.add_to_cart') }}</a>
                    </div>
@else
                    @if(count($checkProductOption)== 0)
                <input type="hidden" name="product_id" id="product-detail-id" value="{{ $product->storage_product_id }}" />

                <div class="group-xs group-middle">
                    <div class="product-stepper">
                      <input class="form-input" name="qty" type="number" data-zeros="true" value="1" min="1" max="100">
                    </div>
                    <div>
                        <button class="button button-lg button-secondary button-zakaria" type="submit">{{ sc_language_render('action.add_to_cart') }}</button>
                    </div>
                </div>
                 @else
                  <div style="display:none;" id="cart" class="group-xs group-middle">
                    <div class="product-stepper">
                      <input class="form-input" name="qty" type="number" data-zeros="true" value="1" min="1" max="100">
                      <input type="hidden" name="storage_id" value="" id='storage_id'/>
                      <input type="hidden" name="product_id" class="storage_id" id="product-detail-id" value="" />

                    </div>
                    <div>
                        <button class="button button-lg button-secondary button-zakaria" type="submit">{{ sc_language_render('action.add_to_cart') }}</button>
                    </div>
                </div>
                  <div id="product-detail-attr">
                 <select name="product_option" id="product_option" onchange="addCart(this.value)">
         <option value="">Select Option</option>
        @foreach($checkProductOption as $option)
        <option value="{{$option->storage_product_id}}">{{$option->title}}</option>
        @endforeach
                 </select> &nbsp;&nbsp;
              <div class="single-product-price" id="product-price2">
                                        </div>
                  </div>
                @endif
                @endif
                 @endif
                {{--// Button add to cart --}}

                {{-- Show attribute --}}
                @if (sc_config('product_property'))
              
                @endif
                {{--// Show attribute --}}

                {{-- Stock info --}}
                @if (sc_config('product_stock'))
                <div>
                    {{ sc_language_render('product.stock_status') }}:
                    <span id="stock_status">
               
                 @php  echo $modelProduct->getStockStatus($product->out_of_stock_status); @endphp
                           
                    </span> 
                </div>
                @endif
                {{--// Stock info --}}

              

                
             

              
                <hr class="hr-gray-100">

                {{-- Social --}}
<!--                <div class="group-xs group-middle"><span class="list-social-title">Share</span>
                  <div>
                    <ul class="list-inline list-social list-inline-sm">
                      <li><a class="icon mdi mdi-facebook" href="#"></a></li>
                      <li><a class="icon mdi mdi-twitter" href="#"></a></li>
                      <li><a class="icon mdi mdi-instagram" href="#"></a></li>
                      <li><a class="icon mdi mdi-google-plus" href="#"></a></li>
                    </ul>
                  </div>
                </div>-->
                {{--// Social --}}

              </div>
            </form>
            </div>
          </div>

          <!-- Bootstrap tabs-->
          <div class="tabs-custom tabs-horizontal tabs-line" id="tabs-1">
            <!-- Nav tabs-->
            <div class="nav-tabs-wrap">
              <ul class="nav nav-tabs nav-tabs-1">
                <li class="nav-item" role="presentation">
                  <a class="nav-link active" href="#tabs-1-1" data-toggle="tab">{{ sc_language_render('product.description') }}</a>
                </li>
              </ul>
            </div>

            {{-- Render connetnt --}}
            <div class="tab-content tab-content-1">
              <div class="tab-pane fade show active" id="tabs-1-1">
                {!! sc_html_render($product->short_description) !!}
              </div>
            </div>
            {{--// Render connetnt --}}

          </div>
        </div>
      </section>


      @if ($productRelation->count())
      <!-- Related Products-->
      <section class="section section-sm section-last bg-default">
        <div class="container">
          <h4 class="font-weight-sbold">{{ sc_language_render('front.products_recommend') }}</h4>
          <div class="row row-lg row-30 row-lg-50 justify-content-center">
            @foreach ($productRelation as $key => $productRel)
            <div class="col-sm-6 col-md-5 col-lg-3">
                  {{-- Render product single --}}
                  @include($sc_templatePath.'.common.product_single_old', ['product' => $productRel])
                  {{-- //Render product single --}}
            </div>
            @endforeach
          </div>
        </div>
      </section>
      @endif

   {{-- Render include view --}}
   @include($sc_templatePath.'.common.include_view')
   {{--// Render include view --}}


<!--/product-details-->
@endsection
{{-- block_main --}}


@push('styles')
{{-- Your css style --}}
@endpush
<script type="text/javascript">
function addCart(show){
   document.getElementById('cart').style.display = "block";    
   document.getElementById('product-detail-id').value = show; 
  // document.getElementById('product-price').innerText="$"+ productPrice;
    
}

</script>

@push('scripts')
{{-- //script here --}}
@endpush
 