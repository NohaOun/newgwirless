@php
/*
$layout_page = home
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
   {{-- Render include view --}}
   @include($sc_templatePath.'.common.include_view')
   {{--// Render include view --}}
@endsection

@push('styles')
@if($style==0)
    <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/style.css')}}">
    @else
     <link rel="stylesheet" href="{{ sc_file($sc_templateFile.'/css/style_'.$style.'.css')}}">
@endif
{{-- Your css style --}}
@endpush

@push('scripts')
{{-- //script here --}}
@endpush
