@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $orders
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
    <div class="col-12 col-sm-12 col-md-9 min-height-37vh">
      <h6>{{ $title }}</h6>
      <form id="formId" action="{{ sc_route('customer.post_rma') }}" method="post" class="box" enctype="multipart/form-data">
                {!! csrf_field() !!}
    
                 <div class="form-group{{ $errors->has('prod') ? ' has-error' : '' }}">
                    <label for="product_id" class="control-label">{{ sc_language_render('Products') }}</label>
                    <select  id="select2" name="product_id" class="is_required validate account_input form-control {{ ($errors->has('prod'))?"input-error":"" }}">
                        <option value="0"> Select Product</option>
                        @foreach($products as $product)
                        <option value="{{$product->id}}"> {{$product->title}}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('prod'))
                    <span class="help-block">
                        {{ $errors->first('prod') }}
                    </span>
                    @endif
            
                </div>
                <!-- Change the `data-field` of buttons and `name` of input field's for multiple plus minus buttons-->

                 <div class="form-group{{ $errors->has('quantity_serial') ? ' has-error' : '' }}">
                    <label for="quantity_serial" class="control-label">{{ sc_language_render('Quantity') }}</label>
                    <input id="quantity_serial"  class="is_required validate account_input form-control {{ ($errors->has('quantity_serial'))?"input-error":"" }}"
                        type="text" name="quantity_serial" value="{{ old('quantity_serial') }}">
                    @if ($errors->has('quantity_serial'))
                    <span class="help-block">
                        {{ $errors->first('quantity_serial') }}
                    </span>
                    @endif
            
                </div>
                <input style="float:right;padding-bottom: 10px" id="add_product" type="button" onclick="addProduct()"  class="button button-lg button-secondary" value="Add Product"/>
                
                <br/> <br/><br/>
                
                <input type="hidden" id="prod" name="prod" value=""/>
                <table style="margin-top: 40px">
                    <tr>
                        <td style="border-bottom:1px solid;font-weight: bold;width: 400px">Product</td>
                        <td style="width: 100px">&nbsp;&nbsp;</td>
                        <td  style="border-bottom:1px solid;font-weight: bold;width: 100px">Quantity</td>
                        <td style="width: 50px">&nbsp;&nbsp;</td>
                        <td  style="border-bottom:1px solid;font-weight: bold;width: 100px">Actions</td>
                    </tr>               
                  
                </table>
                   <table id="data">
                          
                  
                </table>
                <br/><br/>
                <input type="hidden" id="counter" value="1" name="counter" class="counter"/>

               
                 <div class="form-group{{ $errors->has('file_serial') ? ' has-error' : '' }}">
                    <label for="from_date" class="control-label">{{ sc_language_render('Serials file') }}</label>
                    <input  class="is_required validate account_input form-control {{ ($errors->has('file_serial'))?"input-error":"" }}"
                               type="file" name="file_serial" ></textarea>
                    @if ($errors->has('file_serial'))
                    <span class="help-block">
                        {{ $errors->first('file_serial') }}
                    </span>
                    @endif
                </div>
                 <div class="form-group{{ $errors->has('serial') ? ' has-error' : '' }}">
                    <label for="from_date" class="control-label">{{ sc_language_render('Serials') }}</label>
                    <textarea  class="is_required validate account_input form-control {{ ($errors->has('serial'))?"input-error":"" }}"
                               type="text" name="serial" ></textarea>
                    @if ($errors->has('serial'))
                    <span class="help-block">
                        {{ $errors->first('serial') }}
                    </span>
                    @endif
                </div>
                <div class="form-group{{ $errors->has('notes') ? ' has-error' : '' }}">
                    <label for="from_date" class="control-label">{{ sc_language_render('Notes') }}</label>
                    <input  class="is_required validate account_input form-control {{ ($errors->has('notes'))?"input-error":"" }}"
                        type="text" name="notes" value="{{ old('notes') }}">
                    @if ($errors->has('notes'))
                    <span class="help-block">
                        {{ $errors->first('notes') }}
                    </span>
                    @endif
                </div>
                <div class="form-group{{ $errors->has('tracking_number') ? ' has-error' : '' }}">
                    <label for="tracking_number" class="control-label">{{ sc_language_render('tracking number') }}</label>
                    <input  class="is_required validate account_input form-control {{ ($errors->has('tracking_number'))?"input-error":"" }}"
                        type="text" name="tracking_number" value="{{ old('tracking_number') }}">
                    @if ($errors->has('tracking_number'))
                    <span class="help-block">
                        {{ $errors->first('tracking_number') }}
                    </span>
                    @endif
            
                </div>
             <div class="form-group{{ $errors->has('replacement_tracking') ? ' has-error' : '' }}">
                    <label for="replacement_tracking" class="control-label">{{ sc_language_render('Replacements tracking number') }}</label>
                    <input  class="is_required validate account_input form-control {{ ($errors->has('replacement_tracking'))?"input-error":"" }}"
                        type="text" name="replacement_tracking" value="{{ old('replacement_tracking') }}">
                    @if ($errors->has('replacement_tracking'))
                    <span class="help-block">
                        {{ $errors->first('replacement_tracking') }}
                    </span>
                    @endif
            
                </div>
              
                <button type="submit" name="Create" class="button button-lg button-secondary">{{ sc_language_render('Create') }}</button>
            </form>
      
    </div>
  </div>
</div>
</section>
<!--<input type="button" style="width:100"  class="remove" id="remove_'+count+'" onclick="remove('+count+')" value="Remove"/>-->
@endsection
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

<script type="text/javascript">
    
 //$(document).ready(function() {
 // $(window).keydown(function(event){
//      $('form').submit(function(event){
//    if(event.keyCode == 13) {
//      
//      event.preventDefault();
//        addProduct(); 
//      return false;
//    }
//  });
//}); 
//
  //  $("#formId").keydown(function(event){
       $(window).keydown(function(event){
       
     //   $("#add_product").click();
    if(event.keyCode==13){ // enter key has code 13 
       //some ajax code code here 
        $("#add_product").click();
         return false;
    }
});
function addProduct(){

 //   $("#add_product").submit(function (e) {
//e.preventDefault();
 var $counter = $('.counter');
  
 var selected = $('#select2 option:selected');
 var show= $('#select2').val();
 var qty= document.getElementById('quantity_serial').value; 
         var items = [];
 items.push(show); 
 var count=parseInt($counter.val());
 if (show == "0") {
    alert("product must be filled out");
    return false;
  }
 if (qty == "") {
    alert("Quantity must be filled out");
    return false;
  }


  //console.log(items);
 //  document.getElementById('product_title').innerText= selected.html();
 document.getElementById('prod').value=show; 
 // document.getElementById('data').innerHTML= '<tr><input type="text"  value="'+items+'" id="product_id"/><td><span id="product_title">'+selected.html()+'</span></td><td><input style="width:40" type="text" value="'+qty+'" name="qty_'+count+'"></td></tr>';
   $('#data').append('<tr class="input-row" id="data_'+count+'"><td style="width: 400px"><input type="hidden" id="product_'+count+'"  value="'+items+'" name="product_id_'+count+'"/><span id="product_title">'+selected.html()+'</span></td><td style="width: 100px">&nbsp;&nbsp;</td><td><input style="width:100" id="qty_'+count+'" type="text" value="'+qty+'" name="qty_'+count+'"></td><td style="width: 50px">&nbsp;&nbsp;</td><td> <a id="remove_'+count+'" onclick="remove('+count+')" title="Remove Item" alt="Remove Item" href="#" style="margin-left:50px"><i class="fa fa-times" aria-hidden="true"></i></a></td></tr>');
  var index = $('#select2').get(0).selectedIndex;
$('#select2 option:eq(' + index + ')').remove();
      
   
           
    var id = show;
  
    $.ajax({
            url:'getProductTitle',
            type:'get',
            dataType:'json',
           data:{id:id},
                beforeSend: function(){                    
                $('#loading').show();
            },
            success: function(data){
               document.getElementById('product_title').innerText= data;
              if(data.error == 0) {
                location.reload();
              }
            }
        }); 
       //  $counter.val( parseInt($counter.val()) + 1 );

}
  function remove(count) {     
       document.getElementById('data_'+count).innerHTML = "";
     reset_values(count); 
}
function reset_values(count) {
    var oldCount;
    oldCount= document.getElementById('counter').value;
  var newCount = 1;
  //loop through all divs
 // $(".input-row ").each(function() {
   // $(this).find("span").text(count); //set new count to span
// update all inputs after remove one
 var x;
 for(x=1;x<=oldCount;x++){   
   if(x==count){}else{
   // $('#product').attr('name', "product_id_"+ count); //set value
       document.getElementById('product_'+x).name = "product_id_"+ newCount;
       document.getElementById('qty_'+x).name = "qty_"+ newCount;
         document.getElementById('product_'+x).id = "product_"+ newCount;
       document.getElementById('qty_'+x).id = "qty_"+ newCount; 
       document.getElementById('remove_'+x).setAttribute( "onClick", "remove("+newCount+")");
       document.getElementById('remove_'+x).id = "remove_"+ newCount; 

   // $('#qty').attr('name', "qty_"+ count); //set value
   document.getElementById('counter').value =  newCount;
    newCount++; //increment count
    }
    
    }  
   
 // })
   
  }
</script>
