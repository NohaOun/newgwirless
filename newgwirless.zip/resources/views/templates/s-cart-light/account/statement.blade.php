@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $orders
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
    <div class="col-12 col-sm-12 col-md-9 min-height-37vh">
      <h6>{{ $title }}</h6>
      @if (count($statements) ==0)
      <div class="text-danger">
        {{ sc_language_render('front.data_notfound') }}
      </div>
      @else
      <h3>Balance : $@php $balance=$modelProduct->start()->getCustomerBalance();echo   number_format((float)$balance[0]->balance, 2, '.', '');
         
          @endphp</h3>
        <form action="{{ sc_route('customer.post_statement') }}" method="post" class="box">
                {!! csrf_field() !!}
                <div class="form-group{{ $errors->has('from_date') ? ' has-error' : '' }}">
                    <label for="from_date" class="control-label">{{ sc_language_render('From Date') }}</label>
                    <input data-date-format="YYYY-MM-DD" class="is_required validate account_input form-control {{ ($errors->has('from_date'))?"input-error":"" }}"
                        type="date" name="from_date" value="{{ old('from_date') }}">
                    @if ($errors->has('from_date'))
                    <span class="help-block">
                        {{ $errors->first('from_date') }}
                    </span>
                    @endif
                </div>
                <div class="form-group{{ $errors->has('to_date') ? ' has-error' : '' }}">
                    <label for="to_date" class="control-label">{{ sc_language_render('To date') }}</label>
                    <input data-date-format="YYYY-MM-DD" class="is_required validate account_input form-control {{ ($errors->has('to_date'))?"input-error":"" }}"
                        type="date" name="to_date" value="">
                    @if ($errors->has('password'))
                    <span class="help-block">
                        {{ $errors->first('to_date') }}
                    </span>
                    @endif
            
                </div>
            
              
                <button type="submit" name="SubmitLogin" class="button button-lg button-secondary">{{ sc_language_render('Search') }}</button>
            </form>
      <br/>
      <table class="table box table-bordered table-responsive" width="100%">
        <thead>
          <tr>
            <th>Date.</th>
            <th >Source Document	</th>
            <th>{{ sc_language_render('Amount')}}</th>
            <th>{{ sc_language_render('Balance') }}</th>
          </tr>
        </thead>
        <tbody>
          @foreach($statements as $order)
          @php
          $n = (isset($n)?$n:0);
          $n++;
                     $date=date('m/d/Y', strtotime($order->date));
                     $desctiption=$modelProduct->getSourceDocumentURL($order->document_type, $order->document_id);
        
                     @endphp
          <tr>
            <td><span class="item_21_sku">{{ $date }}</span></td>
            <td><span class="item_21_sku">{{ $desctiption }}  </span></td>
            <td align="right">@php // echo number_format((float)$order->amount, 2, '.', '')@endphp
         <?php if(substr($order->amount,0, 1) == "-"){
           $order->amount=  substr($order->amount, 1);         
             echo "($" . number_format((float)$order->amount, 2, '.', '') . ")"; }else{ echo "$<span style='margin-right:4px'>".number_format((float)$order->amount, 2, '.', '')."</span>";}
            ?></td>
            <td align="right">
                  <?php
                
                  if(substr($order->balance,0, 1) == "-"){
           $order->balance=  substr($order->balance, 1);         
           echo "($" . number_format((float)$order->balance, 2, '.', '') . ")"; }else{ echo "$<span style='margin-right:4px'>".number_format((float)$order->balance, 2, '.', '')."</span>";}
            ?>
                @php // echo number_format((float)$order->balance, 2, '.', '')@endphp</td>
            
          </tr>
          @endforeach
         
        </tbody>
      </table>
       <div class="row">
        <div class="col-md-12">
          <div class="box collapsed-box">
              
                <div class="col-xs-12">

                    <a target="_blank" class="btn btn-lg btn-primary "  href="{{ sc_route('customer.statementPrint') }}">
            Print <i class="fa fa-print"></i>
        </a>
    </div>
          </div>

        </div>
      </div>
      @endif
       
          
    </div>
  </div>
</div>
</section>
@endsection