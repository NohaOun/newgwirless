@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $orders
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
      <div class="col-12 col-sm-12 col-md-9 min-height-37vh" style="overflow-x:auto;">
      <h6 class="aside-title">{{ $title }}</h6>
      @if (count($orders) ==0)
      <div class="text-danger">
        {{ sc_language_render('front.data_notfound') }}
      </div>
      @else
      <table class="table box table-bordered table-responsive" width="100%">
        <thead>
          <tr>
            <th style="width: 50px;">No.</th>
            <th style="width: 100px;">Tracking Number</th>
            <th>{{ sc_language_render('order.total') }}</th>
            <th>{{ sc_language_render('Order Status') }}</th>
            <th>{{ sc_language_render('Created At') }}</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          @foreach($orders as $order)
          @php
          $n = (isset($n)?$n:0);
          $n++;
          $date=date('m/d/Y', strtotime($order->create_date));

          @endphp
          <tr>
            <td><span class="item_21_sku">#{{ $order->id }}</span></td>
            <td><span class="item_21_sku">{{ $order->tracking_number }}</span></td>
            <td align="right">
              ${{ number_format((float)$order->total, 2, '.', '') }}
            </td>
            <td>{{ $statusOrder[$order->status]}}</td>
            <td>{{ $date }}</td>
            <td>
              <a href="{{ sc_route('customer.order_detail', ['id' => $order->id ]) }}"><i class="fa fa-indent" aria-hidden="true"></i> {{ sc_language_render('order.detail') }}</a>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
      @endif
    </div>
  </div>
</div>
</section>
@endsection