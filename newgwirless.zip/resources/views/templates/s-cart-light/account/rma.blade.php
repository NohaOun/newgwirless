@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $orders
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
    <div class="col-12 col-sm-12 col-md-9 min-height-37vh">
      <h6>{{ $title }}</h6>
    
      
      <a href="{{ sc_route('customer.get_rma') }}" class="button button-lg button-secondary"> + Submit RMA</a>
      <br/>
      <br/>
      <br/>
      <table class="table box table-bordered table-responsive" width="100%">
        <thead>
          <tr>
            <th>ID.</th>
            <th>Date</th>
            <th >Tracking number	</th>
            <th>{{ sc_language_render('Notes')}}</th>
            <th>{{ sc_language_render('Status') }}</th>
            <th>{{ sc_language_render('View') }}</th>
          </tr>
        </thead>
           
          
        <tbody>
               @if (count($rmas) !=0)
          @foreach($rmas as $order)
          @php
          $n = (isset($n)?$n:0);
          $n++;
          $status=$modelProduct->start()->getRmaStatus($order->status);
           $date=date('m/d/Y', strtotime($order->date));

          @endphp
          <tr>
            <td><span class="item_21_sku">{{ $order->id }}</span></td>
            <td><span class="item_21_sku">{{ $date }}</span></td>
            <td><span class="item_21_sku">{{ $order->tracking_number }}</span></td>
            <td align="right">{{ $order->notes }} </td>
            <td>{{ $status }}</td>
 <td>
              <a href="{{ sc_route('customer.rma_detail', ['id' => $order->id ]) }}"><i class="fa fa-indent" aria-hidden="true"></i> {{ sc_language_render('Rma details') }}</a>
            </td>            
          </tr>
          @endforeach
           @endif
        </tbody>
      </table>
     
    </div>
  </div>
</div>
</section>
@endsection