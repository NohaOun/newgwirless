@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $statusShipping
- $order
- $countries
- $attributesGroup
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
    </div>
    <div class="col-12 col-sm-12 col-md-9 min-height-37vh">
      <h6 class="aside-title">{{ $title }}</h6>
      @if (!$order)
      <div class="text-danger">
        {{ sc_language_render('front.data_notfound') }}
      </div>
      @else
      <div class="row" id="order-body">
     


   <div class="col-sm-6">
    <table  class="table table-bordered">
        <tr><td class="td-title">{{ sc_language_render('order.order_status') }}:</td><td>{{ $statusOrder[$order->status] }}</td></tr>
       
    </table>
  </div>
</div>
 <?php   
 
   $mainOrder = (new \SCart\Core\Front\Models\ShopOrder)->getOrderDeatailsById($order->id);
   $orderPayments = (new \SCart\Core\Front\Models\ShopOrder)->getOrderPayments($order->id);
  
   $companyInfo = (new \SCart\Core\Front\Models\ShopOrder)->getCompanyInfo();
  
  $old_url = config('app.old_url');
                        if (strpos($old_url, '//www.') !== false)
                        {
                            $old_url = str_replace("//www.", "//", $old_url);                         
                        }

 ?>
      <div  class="row">
           <table border="0" style="width:100%; ">
    <tbody>
    <tr>
        <td>
            <div style="margin:0 auto;">
                <table width="100%" border="0"
                       style="margin:0 auto; background:#fff; width:100%; padding-bottom:30px">
                    <tbody>
                    <tr>
                        <td>
                            <table width="100%" border="0">
                                <tbody>
                                <tr>
                                    <td width="70%">
                                        <img class="img_logo"
                                             src="{{ $old_url }}<?php  echo $companyInfo->logo; ?>"
                                             alt="" width="150">
                                    </td>
                                    <td width="30%">
                                        <div class="well">
                                            <address class='my-address'>
                                                <?php echo $companyInfo->address; ?><br>
                                                <abbr title="Phone">Phone:</abbr> <?php echo $companyInfo->phone; ?>
                                                <br/>
                                                <?php echo $companyInfo->website; ?>
                                            </address>
                                        </div>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <table width="100%" border="0">
                    <tbody>
                    <tr>

                        <td width="100%" style="text-align:right">
                            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:13px; line-height:12px; padding-right: 10px;">
                                Invoice Number:  <?php echo $order->id; ?></p>
                        </td>

                    </tr>

                    </tbody>
                </table>
            </div>
        </td>
    </tr>
    </tbody>
</table>
   
   <br><br>
          <table width="100%" border="0"
       style="padding-top:80px">
    <tbody>
    <tr style="font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px; text-align:left;">
        <th colspan='2' style="background-color:#cbcbcb; border:3px solid #cbcbcb;"> Customer</th>
        <th colspan='2' style="background-color:#cbcbcb; border:3px solid #cbcbcb;"> MISC</th>
    </tr>

    <tr>
        <td class="title">Business</td>
        <td>
           <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;   border-bottom:2px #cbcbcb solid;">  <?php echo $mainOrder[0]->business_name; ?></p>
        </td>
        <td class="title">Date</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;"> <?php echo date("M d Y", strtotime($mainOrder[0]->create_time)); ?></p>
        </td>
    </tr>

    <tr>
        <td class="title">Name</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;text-align: left">  <?php echo $mainOrder[0]->first_name.' '. $mainOrder[0]->last_name; ?> </p>
        </td>
        <td class="title">Tracking</td>
        <td>
            <p style="text-decoration: underline;color: #007aff; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($mainOrder[0]->tracking_number == '')
                    echo '-';
                else
                    echo $mainOrder[0]->tracking_number; ?>
            </p>
        </td>
    </tr>


    <tr>
        <td class="title">Address</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                echo implode(', ', array(
                    $mainOrder[0]->street,
                    $mainOrder[0]->building,

                    $mainOrder[0]->state,
                    $mainOrder[0]->zip,

                ));
                ?>
            </p>
        </td>
         <td class="title">Source</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;"> <?php echo $mainOrder[0]->order_source; ?></p>
        </td>
    </tr>

    <tr>
        <td class="title">Phone</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px; line-height:12px; border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($mainOrder[0]->mobile_phone == '')
                    echo '-';
                else
                    echo $mainOrder[0]->mobile_phone; ?>
            </p>
        </td>
    </tr>

    <tr>
        <td class="title">Ship To</td>
        <td>
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px; line-height:12px; border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($mainOrder[0]->ship_to == '')
                    echo '-';
                else
                    echo $mainOrder[0]->ship_to; ?>
            </p>
        </td>
    </tr>
    </tbody>
</table>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="box collapsed-box">
          <div class="table-responsive">
            <table class="table table-bordered">
                <thead style="background-color:#cbcbcb; border:3px solid #cbcbcb;">
                  <tr style="background-color:#cbcbcb; border:3px solid #cbcbcb;">
                    <th>#</th>
                    <th>{{ sc_language_render('product.sku') }}</th>
                    <th>{{ sc_language_render('product.name') }}</th>
                    <th class="product_qty">{{ sc_language_render('product.quantity') }}</th>
                     <th class="product_price">{{ sc_language_render('product.price') }}</th>

                    <th class="product_total">{{ sc_language_render('order.totals.total') }}</th>
                  </tr>
                </thead>
                <tbody>
                      @php
          $data = (new \SCart\Core\Front\Models\ShopOrder)->getOrderById($order->id);
        //  $count=count($data);
         $total = 0;
         $count = 0;
      @endphp
                    @foreach ($data as $item)
                       @php
          $n = (isset($n)?$n:0);
          $n++;
               
          @endphp
                          <tr>
                               <td> {{$n }}
                             
                            </td>
                            <td> {{$item->sku }}
                             
                            </td>
                            <td> {{ $item->title}} </td>
                           <td class="product_qty">{{$item->product_count}} </td>

                            <td class="product_price " align="right">$@php echo  number_format((float)$item->unit_price, 2,  '.', ''); @endphp </td>
                            <td align="right" class="product_total item_id_{{ $item->id }}">$@php echo  number_format((float)$item->product_count * $item->unit_price, 2,  '.', ''); @endphp </td>

                          </tr>
                       @php  
                       $total +=($item->product_count * $item->unit_price);
  $count +=$item->product_count;
                
         @endphp 
                    @endforeach
                      <tr>
                                    

                    <td colspan="3" style="border: 3px solid #cbcbcb;text-align:center">
                        <div style="width:100%;">
                            <div class="total-qty small-td">Total Qty</div>
                        </div>
                    </td>

                    <td class="small-td" style="border-right: 0px !important;border-top: 3px solid #cbcbcb;border-bottom: 3px solid #cbcbcb;">
                @php
                
                
                @endphp      {{$count}}                    </td>


                    <td class="total small-td" style="font-weight: bold;color: #707070 !important;background-color: #cbcbcb;    border: 3px solid #cbcbcb !important;">
                        SubTotal
                    </td>
                    <td style="text-align: right !important;border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                      $@php echo number_format((float)$total, 2, '.', '');@php  @endphp                   </td>


                </tr>
             <tr style="border:none;">
                    <td colspan="4" style="border: none !important"></td>

                    <td class="total small-td td-gray">
                        Tax
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                  $@php echo number_format((float)$item->total_tax_amount, 2, '.', ''); @endphp                       </td>

                </tr>
                <tr style="border:none;">
                    <td colspan="4" style="border: 0px !important"></td>

                    <td class="total small-td td-gray">
                        Shipping
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                        $@php echo number_format((float)$item->transfer_fees, 2, '.', ''); @endphp                       </td>

                </tr>
                <tr style="border:none;">
                    <td colspan="4" style="border: 0px !important"></td>

                    <td class="total small-td td-gray">
                        Discount
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                        $@php echo number_format((float)$item->discount, 2, '.', ''); @endphp                       </td>


                </tr>
                               
                <tr style="border:none;">

                    <td colspan="4" style="border: 0px !important"></td>


                    <td class="total small-td" style="font-weight: bold;color: #707070 !important;background-color: #cbcbcb;    border: 3px solid #cbcbcb !important;">
                        Total
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                $@php  $allTotal=   $total+ $item->total_tax_amount +$item->transfer_fees-$item->discount; echo  number_format((float)$allTotal, 2, '.', ''); @endphp                  </td>

                </tr>

            
                
                </tbody>
              </table>
            </div>
        </div>
        </div>
  <div class="payments" style="margin-top: 20px">
       <h3>Payments:</h3>
    <table>
        <?php
        $i = 1;
        foreach ($orderPayments as $orderPayment) {
            ?>
            <tr>
                <td><?php echo $orderPayment->name . " , "; ?>
                    <?php echo $orderPayment->payment . " - on "; ?>
                    <?php echo date("m/d/y", strtotime($orderPayment->date)) . ' '; ?>
                    <?php echo ($orderPayment->paid) ? 'Paid' : 'Not Paid';
                    echo "  <br>  "; ?></td>
            </tr>
            <?php
        }

        ?>
    </table>
</div>
      </div>

      @php
        //  $dataTotal = \SCart\Core\Front\Models\ShopOrderTotal::getTotal($order->id)
      @endphp
      <div class="row">
        <div class="col-md-12">
          <div class="box collapsed-box">
              
                <div class="col-xs-12">

                    <a target="_blank" class="btn btn-lg btn-primary "  href="{{ sc_route('customer.orderPrint', ['id' => $order->id ]) }}">
            Print <i class="fa fa-print"></i>
        </a>
    </div>
          </div>

        </div>
      </div>


      @endif
    </div>
  </div>
</div>
   
</section>
@endsection
<style>
    .table-responsive {
    overflow-x: visible !important;
}
</style>
<script>
$('.print-window').click(function() {
    window.print();
});
</script>