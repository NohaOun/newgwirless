<!DOCTYPE html>
<html>
<head>
    <title>Statement</title>
        <link rel="icon" href="{{ sc_file(sc_store('icon', null, 'images/icon.png')) }}" type="image/png" sizes="16x16">

     <style>

        .table {
            border-collapse: collapse;
        }

        .table th {
            background: #cbcbcb url('example.png') no-repeat top left;
        }


        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
            border: 3px solid #cbcbcb;
            text-align: center;
            padding: 10px;
        }

        @media (min-width: 320px) {


            .misc-content {
                margin-top: 50px;
            }

            .well {
                padding: 5px;
            }

            .my-address {
                margin-bottom: 0px;
            }

            .img-title {
                width: 80px;
            }

        }


        @media (min-width: 961px) {

            .well {
                padding: 25px;
                padding-right: 0px;
                width: 300px;
            }

            .my-address {
                margin-bottom: 20px;
            }
        }

        @media (min-width: 1025px) {

            .misc-content {
                margin-top: 0px;

            }
        }

        .img_logo{
            width: 200px;
            height: 200px;
        }
        .title{
            color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;
        }
        .total{
            background-color:#cbcbcb !important;
            border:3px solid #cbcbcb !important;
        }
    </style>
</head>
<body>
   <!-- customer info -->
   <?php   
   $statements =(new \SCart\Core\Front\Models\ShopProduct)->getCustomerStatement();
   $companyInfo = (new \SCart\Core\Front\Models\ShopOrder)->getCompanyInfo();
  
  // $companyInfo = CompanyInfo::model()->findByPk(1);
  $old_url = config('app.old_url');
                        if (strpos($old_url, '//www.') !== false)
                        {
                            $old_url = str_replace("//www.", "//", $old_url);                         
                        }
 ?>
   <table border="0" style="width:100%; margin-bottom: 150px;">
    <tbody>
    <tr>
        <td>
            <div style="margin:0 auto;">
                <table width="100%" border="0"
                       style="margin:0 auto; background:#fff; width:100%;">
                    <tbody>
                    <tr>
                        <td>
                            <table width="100%" border="0">
                                <tbody>
                                <tr>
                                    <td width="70%">
                                        <img class="img_logo"
                                             src="{{ $old_url}}<?php  echo $companyInfo->logo; ?>"
                                             alt="">
                                    </td>
                                    <td width="30%">
                                        <div class="well">
                                            <address class='my-address'>
                                                <?php echo $companyInfo->address; ?><br>
                                                <abbr title="Phone">Phone:</abbr> <?php echo $companyInfo->phone; ?>
                                                <br/>
                                                <?php echo $companyInfo->website; ?>
                                            </address>
                                        </div>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
             
            </div>
        </td>
    </tr>
    </tbody>
</table>
   <br/>  <br/>
   <table class="table box table-bordered table-responsive" width="100%" style="margin-top:50px">
        <thead>
          <tr>
            <th>Date.</th>
            <th >Source Document	</th>
            <th>{{ sc_language_render('Amount')}}</th>
            <th>{{ sc_language_render('Balance') }}</th>
          </tr>
        </thead>
        <tbody>
          @foreach($statements as $order)
          @php
          $n = (isset($n)?$n:0);
          $n++;
                     $date=date('m/d/Y', strtotime($order->date));
                     $desctiption=$modelProduct->getSourceDocumentURL($order->document_type, $order->document_id);
        
                     @endphp
          <tr>
            <td><span class="item_21_sku">{{ $date }}</span></td>
            <td><span class="item_21_sku">{{ $desctiption }}  </span></td>
            <td align="right">@php // echo number_format((float)$order->amount, 2, '.', '')@endphp
         <?php if(substr($order->amount,0, 1) == "-"){
           $order->amount=  substr($order->amount, 1);         
             echo "($" . number_format((float)$order->amount, 2, '.', '') . ")"; }else{ echo "$".number_format((float)$order->amount, 2, '.', '');}
            ?></td>
            <td align="right">$@php echo number_format((float)$order->balance, 2, '.', '')@endphp</td>
            
          </tr>
          @endforeach
        </tbody>
      </table>

</body>
</html>
