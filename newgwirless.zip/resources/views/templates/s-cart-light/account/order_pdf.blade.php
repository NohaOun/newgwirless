<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
  <link rel="icon" href="{{ sc_file(sc_store('icon', null, 'images/icon.png')) }}" type="image/png" sizes="16x16">

     <style>

        .table {
            border-collapse: collapse;
        }

        .table th {
            background: #cbcbcb url('example.png') no-repeat top left;
        }


        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
            border: 3px solid #cbcbcb;
            text-align: center;
            padding: 10px;
        }

        @media (min-width: 320px) {


            .misc-content {
                margin-top: 50px;
            }

            .well {
                padding: 5px;
            }

            .my-address {
                margin-bottom: 0px;
            }

            .img-title {
                width: 80px;
            }

        }


        @media (min-width: 961px) {

            .well {
                padding: 25px;
                padding-right: 0px;
                width: 300px;
            }

            .my-address {
                margin-bottom: 20px;
            }
        }

        @media (min-width: 1025px) {

            .misc-content {
                margin-top: 0px;

            }
        }

        .img_logo{
            width: 200px;
            height: 200px;
        }
        .title{
            color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;
        }
        .total{
            background-color:#cbcbcb !important;
            border:3px solid #cbcbcb !important;
        }
    </style>
</head>
<body>
   <!-- customer info -->
   <?php   
   $order = (new \SCart\Core\Front\Models\ShopOrder)->getOrderDeatailsById($id);
   $orderPayments = (new \SCart\Core\Front\Models\ShopOrder)->getOrderPayments($id);
   $companyInfo = (new \SCart\Core\Front\Models\ShopOrder)->getCompanyInfo();
  
  // $companyInfo = CompanyInfo::model()->findByPk(1);
  $old_url = config('app.old_url');
                        if (strpos($old_url, '//www.') !== false)
                        {
                            $old_url = str_replace("//www.", "//", $old_url);                         
                        }
 ?>
   <table border="0" style="width:100%; margin-bottom: 150px;">
    <tbody>
    <tr>
        <td>
            <div style="margin:0 auto;">
                <table width="100%" border="0"
                       style="margin:0 auto; background:#fff; width:100%;">
                    <tbody>
                    <tr>
                        <td>
                            <table width="100%" border="0">
                                <tbody>
                                <tr>
                                    <td width="70%">
                                        <img class="img_logo"
                                             src="{{ $old_url}}<?php  echo $companyInfo->logo; ?>"
                                             alt="">
                                    </td>
                                    <td width="30%">
                                        <div class="well">
                                            <address class='my-address'>
                                                <?php echo $companyInfo->address; ?><br>
                                                <abbr title="Phone">Phone:</abbr> <?php echo $companyInfo->phone; ?>
                                                <br/>
                                                <?php echo $companyInfo->website; ?>
                                            </address>
                                        </div>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
             
            </div>
        </td>
    </tr>
    </tbody>
</table>
      <table width="100%" border="0">
                    <tbody>
                    <tr>

                        <td width="100%" style="text-align:right">
                            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:20px;margin-bottom: 5px;  ">
                                Invoice Number:  <?php echo $id; ?></p>
                        </td>

                    </tr>

                    </tbody>
                </table>
  

<table width="100%" border="0"
      >
    <tbody>
    <tr style="font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px; text-align:left;">
        <th colspan='2' style="background-color:#cbcbcb; border:3px solid #cbcbcb;"> Customer</th>
        <th colspan='2' style="background-color:#cbcbcb; border:3px solid #cbcbcb;"> MISC</th>
    </tr>

    <tr>
        <td class="title">Business</td>
        <td style="line-height:3px">
           <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;   border-bottom:2px #cbcbcb solid;">  <?php echo $order[0]->business_name; ?></p>
        </td>
        <td class="title">Date</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;"> <?php echo date("M d Y", strtotime($order[0]->create_time)); ?></p>
        </td>
    </tr>

    <tr>
        <td class="title">Name</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">  <?php echo $order[0]->first_name.' '. $order[0]->last_name; ?> </p>
        </td>
        <td class="title">Tracking</td>
        <td style="line-height:3px">
            <p style="text-decoration: underline;color: #007aff; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($order[0]->tracking_number == '')
                    echo '-';
                else
                    echo $order[0]->tracking_number; ?>
            </p>
        </td>
    </tr>


    <tr>
        <td class="title">Address</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                echo implode(', ', array(
                    $order[0]->street,
                    $order[0]->building,

                    $order[0]->state,
                    $order[0]->zip,

                ));
                ?>
            </p>
        </td>
         <td class="title">Source</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;"> <?php echo $order[0]->order_source; ?></p>
        </td>
    </tr>

    <tr>
        <td class="title">Phone</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px; border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($order[0]->mobile_phone == '')
                    echo '-';
                else
                    echo $order[0]->mobile_phone; ?>
            </p>
        </td>
    </tr>

    <tr>
        <td class="title">Ship To</td>
        <td style="line-height:3px">
            <p style="color:#343333; font-family:Helvetica,Arial,sans-serif; font-weight:bold; font-size:12px;  border-bottom:2px #cbcbcb solid;margin-top:0px;">
                <?php
                if ($order[0]->ship_to == '')
                    echo '-';
                else
                    echo $order[0]->ship_to; ?>
            </p>
        </td>
    </tr>
    </tbody>
</table>
   
         <div class="row">
        <div class="col-sm-12">
          <div class="box collapsed-box">
          <div class="table-responsive">
            <table class="table table-bordered" width='100%'>
                <thead>
                  <tr>
                    <th class="total">#</th>
                    <th class="total">{{ sc_language_render('product.sku') }}</th>
                    <th class="total">{{ sc_language_render('product.name') }}</th>
                    <th class="total product_qty">{{ sc_language_render('product.quantity') }}</th>
                     <th class="total product_price">{{ sc_language_render('product.price') }}</th>

                    <th class="total product_total">{{ sc_language_render('order.totals.total') }}</th>
                  </tr>
                </thead>
                <tbody>
                      @php
        //  $data = (new \SCart\Core\Front\Models\ShopOrder)->getOrderById($id);
       
         $total = 0;
         $count = 0;
      @endphp
                    @foreach ($order as $item)
                       @php
          $n = (isset($n)?$n:0);
          $n++;
               
          @endphp
                          <tr>
                               <td> {{$n }}
                             
                            </td>
                            <td> {{$item->sku }}
                             
                            </td>
                            <td> {{ $item->title}} </td>
                           <td class="product_qty">{{$item->product_count}} </td>

                            <td align="left" style="text-align: right !important;">$@php echo   number_format((float)$item->unit_price, 2, '.', ''); @endphp </td>
                            <td align="right" class="small-td" style="text-align: right !important;" >$@php echo number_format((float)($item->product_count * $item->unit_price), 2, '.', ''); @endphp </td>

                          </tr>
                       @php  
                       $total +=($item->product_count * $item->unit_price);
  $count +=$item->product_count;
                
         @endphp 
                    @endforeach
                      <tr>
                                    

                    <td colspan="3" style="border: 3px solid #cbcbcb;text-align:center">
                        <div style="width:100%;">
                            <div class="total-qty small-td">Total Qty</div>
                        </div>
                    </td>

                    <td class="small-td" style="border-right: 0px !important;border-top: 3px solid #cbcbcb;border-bottom: 3px solid #cbcbcb;">
                @php
                
                
                @endphp      {{$count}}                    </td>


                    <td class="total small-td" style="font-weight: bold;color: #707070 !important;background-color: #cbcbcb;    border: 3px solid #cbcbcb !important;">
                        SubTotal
                    </td>
                    <td style="text-align: right !important;border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                      $@php echo number_format((float)$total, 2, '.', ''); @endphp                  </td>


                </tr>
             <tr style="border:none;">
                    <td colspan="4" style="border: none !important"></td>

                    <td class="total small-td td-gray">
                        Tax
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                  $@php echo number_format((float)$item->total_tax_amount, 2, '.', ''); @endphp                       </td>

                </tr>
                <tr style="border:none;">
                    <td colspan="4" style="border: 0px !important"></td>

                    <td class="total small-td td-gray">
                        Shipping
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                        $@php echo number_format((float)$item->transfer_fees, 2, '.', ''); @endphp                       </td>

                </tr>
                <tr style="border:none;">
                    <td colspan="4" style="border: 0px !important"></td>

                    <td class="total small-td td-gray">
                        Discount
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                        $@php echo number_format((float)$item->discount, 2, '.', ''); @endphp                       </td>


                </tr>
                               
                               
                <tr style="border:none;">

                    <td colspan="4" style="border: 0px !important"></td>


                    <td class="total small-td" style="font-weight: bold;color: #707070 !important;background-color: #cbcbcb;    border: 3px solid #cbcbcb !important;">
                        Total
                    </td>
                    <td style="border: 3px solid #cbcbcb; text-align: right !important;" class="small-td">
                 $@php  $allTotal=   $total+ $item->total_tax_amount +$item->transfer_fees-$item->discount; echo number_format((float)$allTotal, 2, '.', ''); @endphp                  </td>

                </tr>

            
                
                </tbody>
              </table>
            </div>
        </div>
        </div>

      </div>
   <div class="payments" style="margin-top: 20px">
       <h3>Payments:</h3>
    <table>
        <?php
        $i = 1;
        foreach ($orderPayments as $orderPayment) {
            ?>
            <tr>
                <td><?php echo $orderPayment->name . " , "; ?>
                    <?php echo $orderPayment->payment . " - on "; ?>
                    <?php echo date("m/d/y", strtotime($orderPayment->date)) . ' '; ?>
                    <?php echo ($orderPayment->paid) ? 'Paid' : 'Not Paid';
                    echo "  <br>  "; ?></td>
            </tr>
            <?php
        }

        ?>
    </table>
</div>
   <div class="row notes">
    <div class="col-xs-12">
        <h5>
            <?php
            if ($order[0]->notes != "")
                echo "Notes : <br> <br>";
            echo $order[0]->notes . '<br>';
           
            ?>
        </h5>
    </div>
</div>
</body>
</html>
