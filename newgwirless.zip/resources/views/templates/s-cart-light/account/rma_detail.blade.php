@php
/*
$layout_page = shop_profile
** Variables:**
- $statusOrder
- $orders
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
  <div class="row">
    <div class="col-12 col-sm-12 col-md-3">
      @include($sc_templatePath.'.account.nav_customer')
      @php       
        $date=date('m/d/Y', strtotime($rma->date));
      @endphp
    </div>
    <div class="col-12 col-sm-12 col-md-9 min-height-37vh">
      <h6>{{ $title }}</h6>
            <table class="table box table-bordered table-responsive col-md-5" style="float: left;margin-right:20px" id="yw0">
        <tbody><tr><th style="width:20%">Num#</th><td>{{$rma_id}}</td></tr>
            <tr><th style="width:20%">Date</th><td>{{$date}}</td></tr>
            <tr><th style="width:20%">Status</th><td>{{$statusRma}}</td></tr>
            <tr><th style="width:20%">Customer</th><td>{{$rma->business_name}}</td></tr>
            <tr><th style="width:20%">Created By</th><td>{{$rma->business_name}}</td></tr>
        </tbody></table>
  

          <table class="table box table-bordered table-responsive col-md-5"  id="yw1">
          <tbody>
              <tr><th style="width:50% !important">Tracking Number</th><td>{{$rma->tracking_number}}</td></tr>
              <tr><th style="width:50% !important">Replacement's tracking number</th><td>{{$rma->replacement_tracking}}</td></tr>
              <tr><th style="width:50% !important">Replaced from storage</th><td>{{$from_storage}}</td></tr>
              <tr><th style="width:50% !important">RMA storage</th><td>{{$rma_storage}}</td></tr>
          </tbody></table>


      <table class="table box table-bordered table-responsive" width="100%">
        <thead>
          <tr>
            <th>#</th>
            <th>Item</th>
            <th >Quantity	</th>
            <th>{{ sc_language_render('Approved')}}</th>
            <th>{{ sc_language_render('Rejected') }}</th>
            <th>{{ sc_language_render('Refunded Qunatity') }}</th>
            <th>{{ sc_language_render('Refund') }}</th>
            <th>{{ sc_language_render('Note') }}</th>
          </tr>
        </thead>
           
          
        <tbody>
        
             @if (count($products) !=0)
          @foreach($products as $product)
          @php
          $n = (isset($n)?$n:0);
          $n++;
        

          @endphp
          <tr>
            <td><span class="item_21_sku">{{ $n }}</span></td>
            <td><span class="item_21_sku">{{ $product['title'] }}</span></td>
            <td><span class="item_21_sku">{{ $product['qty'] }}</span></td>
            <td><span class="item_21_sku">{{ $product['approved'] }}</span></td>
            <td><span class="item_21_sku">{{ $product['rejected'] }}</span></td>
            <td><span class="item_21_sku">{{ $product['refunded'] }}</span></td>
            <td align="right">@php  echo number_format((float)$product['Refund'] , 2, '.', '')@endphp</td>
            <td>{{ $product['note'] }}</td>
         
          </tr>
          @endforeach
           @endif
        
        </tbody>
      </table>
     
        <table class="table box table-bordered table-responsive" width="100%">
        <thead>
          <tr>
            <th>Product Id</th>
            <th>Sku</th>
            <th >Serial	</th>
            <th>Given Serial</th>
            <th>Note</th>
         
          </tr>
        </thead>
           
          
        <tbody>
         
            @if (count($serials) !=0)
          @foreach($serials as $product)
          
          <tr>
            <td><span class="item_21_sku">{{ $product->title }}</span></td>
            <td><span class="item_21_sku">{{ $product->sku }}</span></td>
            <td><span class="item_21_sku">{{ $product->serial }}</span></td>
            <td><span class="item_21_sku">{{ $product->given_serial }}</span></td>
            <td><span class="item_21_sku">{{ $product->note }}</span></td>
          
          </tr>
             @endforeach
           @endif
        
        
        </tbody>
      </table>
    </div>
  </div>
</div>
</section>
@endsection