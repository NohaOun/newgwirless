@php
/*
$layout_page = shop_profile
** Variables:**
- $customer
- $countries
*/ 
@endphp

@extends($sc_templatePath.'.layout')

@section('block_main')
<section class="section section-sm section-first bg-default text-md-left">
<div class="container">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-3">
            @include($sc_templatePath.'.account.nav_customer')
        </div>
        <div class="col-12 col-sm-12 col-md-9">
            <h6 class="aside-title">{{ $title }}</h6>
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ sc_route('customer.post_change_infomation') }}">
                        @csrf
                        @if (sc_config('customer_lastname'))
                        <div class="form-group row {{ $errors->has('first_name') ? ' has-error' : '' }}">
                            <label for="first_name"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.first_name') }}</label>

                            <div class="col-md-6">
                                <input id="first_name" type="text" class="form-control" name="first_name" 
                                    value="{{ (old('first_name'))?old('first_name'):$customer['first_name']}}">

                                @if($errors->has('first_name'))
                                <span class="help-block">{{ $errors->first('first_name') }}</span>
                                @endif

                            </div>
                        </div>
                        <div class="form-group row {{ $errors->has('last_name') ? ' has-error' : '' }}">
                            <label for="last_name"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.last_name') }}</label>

                            <div class="col-md-6">
                                <input id="last_name" type="text" class="form-control" name="last_name" 
                                    value="{{ (old('last_name'))?old('last_name'):$customer['last_name']}}">

                                @if($errors->has('last_name'))
                                <span class="help-block">{{ $errors->first('last_name') }}</span>
                                @endif

                            </div>
                        </div>
                        @else
                        <div class="form-group row {{ $errors->has('first_name') ? ' has-error' : '' }}">
                            <label for="first_name"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.name') }}</label>

                            <div class="col-md-6">
                                <input id="first_name" type="text" class="form-control" name="first_name" 
                                    value="{{ (old('first_name'))?old('first_name'):$customer['first_name']}}">

                                @if($errors->has('first_name'))
                                <span class="help-block">{{ $errors->first('first_name') }}</span>
                                @endif

                            </div>
                        </div>
                        @endif

                      

                        @if (sc_config('customer_phone'))
                        <div class="form-group row {{ $errors->has('mobile_phone') ? ' has-error' : '' }}">
                            <label for="phone"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.phone') }}</label>

                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control" name="mobile_phone" 
                                    value="{{ (old('mobile_phone'))?old('mobile_phone'):$customer['mobile_phone']}}">

                                @if($errors->has('phone'))
                                <span class="help-block">{{ $errors->first('mobile_phone') }}</span>
                                @endif

                            </div>
                        </div>
                        @endif

                        @if (sc_config('customer_postcode'))
                        <div class="form-group row {{ $errors->has('zip') ? ' has-error' : '' }}">
                            <label for="postcode"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.postcode') }}</label>

                            <div class="col-md-6">
                                <input id="postcode" type="text" class="form-control" name="zip" 
                                    value="{{ (old('zip'))?old('zip'):$customer['zip']}}">

                                @if($errors->has('postcode'))
                                <span class="help-block">{{ $errors->first('zip') }}</span>
                                @endif

                            </div>
                        </div>
                        @endif

                        <div class="form-group row {{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.email') }}</label>

                            <div class="col-md-6">
                                {{ $customer['email'] }}

                            </div>
                        </div>

                        <div class="form-group row {{ $errors->has('street') ? ' has-error' : '' }}">
                            <label for="address1"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.address1') }}</label>

                            <div class="col-md-6">
                                <input id="address1" type="text" class="form-control" name="street" 
                                    value="{{ (old('street'))?old('street'):$customer['street']}}">

                                @if($errors->has('address1'))
                                <span class="help-block">{{ $errors->first('street') }}</span>
                                @endif

                            </div>
                        </div>


                        @if (sc_config('customer_address2'))
                        <div class="form-group row {{ $errors->has('building') ? ' has-error' : '' }}">
                            <label for="address2"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.address2') }}</label>
                            <div class="col-md-6">
                                <input id="address2" type="text" class="form-control" name="building" 
                                    value="{{ (old('building'))?old('building'):$customer['building']}}">

                                @if($errors->has('address2'))
                                <span class="help-block">{{ $errors->first('building') }}</span>
                                @endif

                            </div>
                        </div>
                        @endif


<!--                        @if (sc_config('customer_address3'))
                        <div class="form-group row {{ $errors->has('address3') ? ' has-error' : '' }}">
                            <label for="address3"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('customer.address3') }}</label>
                            <div class="col-md-6">
                                <input id="address3" type="text" class="form-control" name="address3" 
                                    value="{{ (old('address3'))?old('address3'):$customer['address3']}}">

                                @if($errors->has('address3'))
                                <span class="help-block">{{ $errors->first('address3') }}</span>
                                @endif

                            </div>
                        </div>
                        @endif-->


                    @if (sc_config('customer_country'))
                     @php
                        $country = (old('state'))?old('state'):$customer['state'];
                        @endphp

                    <div class="form-group row {{ $errors->has('state') ? ' has-error' : '' }}">
                       <label for="address2"
                                class="col-md-4 col-form-label text-md-right">{{ sc_language_render('State') }}</label>
                            <div class="col-md-6">
                        <select id="select2" class="form-control country" style="width: 100%;" name="state">
                            <option  style="color: #495057">State</option>
                            @foreach ($countries as $k => $v)
                            <option value="{{ $k }}" {{ ($customer['state'] ==$k) ? 'selected':'' }}>{{ $v }}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('state'))
                        <span class="help-block">
                            {{ $errors->first('state') }}
                        </span>
                        @endif
                    </div>
                    </div>
                    @endif
            

                      


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ sc_language_render('customer.update_infomation') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
@endsection
