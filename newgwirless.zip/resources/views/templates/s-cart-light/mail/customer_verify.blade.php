@extends($sc_templatePath.'.mail.layout')

@section('main')
  {!! $content??'' !!}
@endsection
