      <!-- Page Header-->
      <header class="section page-header">
        <!-- RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static" data-lg-stick-up-offset="100px" data-xl-stick-up-offset="100px" data-xxl-stick-up-offset="100px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!-- RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!-- RD Navbar Brand-->
                  <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="{{ sc_route('home') }}"><img class="brand-logo-dark" src="{{config('app.url')}}/{{ sc_store('logo', ($storeId ?? null)) }}" alt="" width="105" height="44"/>
                   
                        <img class="brand-logo-light" src="{{config('app.url')}}/{{ sc_store('logo', ($storeId ?? null)) }}" alt="" width="106" height="44"/></a>
                  </div>
                </div>
                <div class="rd-navbar-nav-wrap">
                  <!-- RD Navbar Nav-->
                  <ul class="rd-navbar-nav">
                    <li class="rd-nav-item active"><a class="rd-nav-link" href="{{ sc_route('home') }}">{{ sc_language_render('front.home') }}</a></li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="{{ sc_route('shop') }}">{{ sc_language_render('front.shop') }}</a></li>
                    @if (!empty($sc_layoutsUrl['menu']))
                    @foreach ($sc_layoutsUrl['menu'] as $url)
                    <li class="rd-nav-item">
                        <a class="rd-nav-link" {{ ($url->target =='_blank')?'target=_blank':''  }}
                            href="{{ sc_url_render($url->url) }}">{{ sc_language_render($url->name) }}</a>
                    </li>
                    @endforeach
                    @endif

                    @guest
                    <li class="rd-nav-item"><a class="rd-nav-link" href="{{ sc_route('login') }}"><i class="fa fa-lock"></i> {{ sc_language_render('front.login') }}</a>
                    <!--      <ul class="rd-menu rd-navbar-dropdown">
                            <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('login') }}"><i class="fa fa-user"></i> {{ sc_language_render('front.login') }}</a>
                            </li>

                          <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('wishlist') }}"><i class="fas fa-heart"></i> {{ sc_language_render('front.wishlist') }} 
                                    <span class="count sc-wishlist"
                                    id="shopping-wishlist">{{ Cart::instance('wishlist')->count() }}</span>
                                </a>
                            </li>
                            <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('compare') }}"><i class="fa fa-exchange"></i> {{ sc_language_render('front.compare') }} 
                                    <span class="count sc-compare"
                                    id="shopping-compare">{{ Cart::instance('compare')->count() }}</span>
                                </a>
                            </li>
                        </ul>-->
                    </li>

                    @else
                    <li class="rd-nav-item"><a class="rd-nav-link" href="#"><i class="fa fa-lock"></i> {{ sc_language_render('customer.my_profile') }}</a>
                        <ul class="rd-menu rd-navbar-dropdown">
                            <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="{{ sc_route('customer.index') }}"><i class="fa fa-user"></i> {{ sc_language_render('front.my_profile') }}</a></li>
                            <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="{{ sc_route('logout') }}" rel="nofollow" onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();"><i class="fa fa-power-off"></i> {{ sc_language_render('front.logout') }}</a></li>
<!--                            <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('wishlist') }}"><i class="fas fa-heart"></i> {{ sc_language_render('front.wishlist') }} 
                                    <span class="count sc-wishlist"
                                    id="shopping-wishlist">{{ Cart::instance('wishlist')->count() }}</span>
                                </a>
                            </li>
                            <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('compare') }}"><i class="fa fa-exchange"></i> {{ sc_language_render('front.compare') }} 
                                    <span class="count sc-compare"
                                    id="shopping-compare">{{ Cart::instance('compare')->count() }}</span>
                                </a>
                            </li>-->
                            <form id="logout-form" action="{{ sc_route('logout') }}" method="POST" style="display: none;">
                              @csrf
                            </form>
                        </ul>
                    </li>
                    @endguest


                    @if (count($sc_languages)>1)
                    <li class="rd-nav-item">
                        <a class="rd-nav-link" href="#">
                            <img src="{{ sc_file($sc_languages[app()->getLocale()]['icon']) }}" style="height: 25px;"> <i class="fas fa-caret-down"></i>
                        </a>
                        <ul class="rd-menu rd-navbar-dropdown">
                            @foreach ($sc_languages as $key => $language)
                            <li class="rd-dropdown-item">
                                <a class="rd-dropdown-link" href="{{ sc_route('locale', ['code' => $key]) }}">
                                    <img src="{{ sc_file($language['icon']) }}" style="height: 25px;"> {{ $language['name'] }}
                                </a>
                            </li>
                            @endforeach
                        </ul>
                    </li>
                    @endif

                    @if (count($sc_currencies)>1)
                    <li class="rd-nav-item">
                        <a class="rd-nav-link" href="#">
                            {{ sc_currency_info()['name'] }} <i class="fas fa-caret-down"></i>
                        </a>
                        <ul class="rd-menu rd-navbar-dropdown">
                            @foreach ($sc_currencies as $key => $currency)
                            <li class="rd-dropdown-item" {{ ($currency->code ==  sc_currency_info()['code']) ? 'disabled': '' }}>
                                <a class="rd-dropdown-link" href="{{ sc_route('currency', ['code' => $currency->code]) }}">
                                    {{ $currency->name }}
                                </a>
                            </li>
                            @endforeach
                        </ul>
                    </li>
                    @endif

                  </ul>
                </div>

                <div class="rd-navbar-main-element">
                  <!-- RD Navbar Search-->
                  <div class="rd-navbar-search rd-navbar-search-2">
                    <button class="rd-navbar-search-toggle rd-navbar-fixed-element-3" data-rd-navbar-toggle=".rd-navbar-search"><span></span></button>
                    <form class="rd-search" action="{{ sc_route('search') }}"  method="GET">
                      <div class="form-wrap">
                        <input class="rd-navbar-search-form-input form-input"  type="text" name="keyword"  placeholder="{{ sc_language_render('Search') }}"/>
                        <button class="rd-search-form-submit" type="submit"></button>
                      </div>
                    </form>
                  </div>
                  <!-- RD Navbar Basket-->
                  <div class="rd-navbar-basket-wrap">
                    <a href="{{ sc_route('cart') }}">
                    <button class="rd-navbar-basket fl-bigmug-line-shopping202">
                      <span class="count sc-cart" id="shopping-cart">{{ Cart::instance('default')->count() }}</span>
                    </button>
                    </a>
                  </div>
                  <a title="{{ sc_language_render('cart.page_title') }}" style="margin-top:10px;" class="rd-navbar-basket rd-navbar-basket-mobile fl-bigmug-line-shopping202 rd-navbar-fixed-element-2" href="{{ sc_route('cart') }}">
                    <span class="count sc-cart">{{ Cart::instance('default')->count() }}</span>
                 </a>
                   
                </div>
              </div>
            </div>
                
<ul id="menu">
     @php
echo $modelCategory->start()->getCategoryChild();
@endphp


	
	
</ul>
              
          </nav>
            
        </div>
      </header>
  
   <style>
    
      /*   max-height:500px;you can change as you need it */
   /* overflow:auto;/* to get scroll */
   
    
    /* Menu Styles */

.parent {display: inline-block;position: relative;line-height: 30px;background-color: #f2f2f2;border-right:#CCC 1px solid;}
.parent a{margin: 10px;color: #000;text-decoration: none;}
.parent:hover > ul {display:block;position:absolute;}
.child {display: none;}
.child li {background-color: #E4EFF7 !important;line-height: 30px;border-bottom:#CCC 1px solid;border-right:#CCC 1px solid; width:100%;}
.child li a{color: #000000;}
ul{list-style: none;margin: 0;padding: 0px; min-width:10em;}
ul ul ul{left: 100%;top: 0;margin-left:1px;}
li:hover {background-color: #95B4CA;}
.parent li:hover {background-color: #F0F0F0;}
.expand{font-size:12px;float:right;margin-right:5px;}
.child-div { /*width: 800px; max-height: 500px; overflow-y: auto;overflow-x: hidden; */background: white;}
li.parent.lvl2 {width: 200px;display: block;z-index: 999;}



</style>
