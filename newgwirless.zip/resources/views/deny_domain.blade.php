<div style="margin: auto; width: 50%; text-align:center">
<h2 style="color: red"> {!!  sc_language_render('store.deny_help_1') !!}</h2>
<h3> {!!  sc_language_render('store.deny_help_2') !!} <a href="{{ config('app.url') }}">{!!  sc_language_render('action.click_here') !!}</a></h3>
</div>
